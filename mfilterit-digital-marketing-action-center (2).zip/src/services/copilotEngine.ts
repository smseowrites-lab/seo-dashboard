import { TaskRecommendation, CompetitorEvent } from '../types';
import { 
  MFILTERIT_MASTER_KNOWLEDGE, 
  StoredMemoryItem, 
  UploadedFile 
} from '../data/knowledgeBase';

export interface CopilotResponse {
  text: string;
  sourcesUsed: string[];
  actionType?: 'EXECUTE_TASK' | 'CREATE_CAROUSEL' | 'OPTIMIZE_AEO' | 'OPTIMIZE_GEO' | 'VIEW_MEMORY' | 'GENERAL';
  targetTaskId?: string;
  targetTask?: TaskRecommendation;
  followUpSuggestions?: string[];
  suggestedTitle?: string;
}

export function generateConversationTitle(firstPrompt: string): string {
  const lower = firstPrompt.toLowerCase();
  if (lower.includes('aaj kya karna') || lower.includes('what should i do') || lower.includes('today')) {
    return "Today's Action Plan";
  }
  if (lower.includes('meta ads') || lower.includes('advantage+')) {
    return "Meta Ads Click Fraud Strategy";
  }
  if (lower.includes('app fraud') || lower.includes('install fraud') || lower.includes('sdk')) {
    return "Mobile App Install Fraud Triage";
  }
  if (lower.includes('competitor') || lower.includes('cheq') || lower.includes('appsflyer')) {
    return "Competitor Activity Radar";
  }
  if (lower.includes('carousel') || lower.includes('canva') || lower.includes('linkedin')) {
    return "LinkedIn Carousel Studio";
  }
  if (lower.includes('aeo') || lower.includes('question') || lower.includes('snippet')) {
    return "AEO & PAA Opportunity Analysis";
  }
  if (lower.includes('geo') || lower.includes('perplexity') || lower.includes('chatgpt')) {
    return "Generative Search Strategy";
  }
  // Trim first 5 words
  const words = firstPrompt.trim().split(/\s+/).slice(0, 5).join(' ');
  return words.length > 25 ? `${words.slice(0, 25)}...` : words;
}

export async function processCopilotQuery(
  userQuery: string,
  history: { sender: 'user' | 'assistant'; text: string }[],
  tasks: TaskRecommendation[],
  competitorEvents: CompetitorEvent[],
  memoryItems: StoredMemoryItem[],
  uploadedFiles: UploadedFile[]
): Promise<CopilotResponse> {
  const lower = userQuery.toLowerCase().trim();

  // 1. "Aaj kya karna hai?" / "What should I do today?" / "Today's plan"
  if (
    lower.includes('aaj kya karna hai') || 
    lower.includes('what should i do today') || 
    lower.includes('todays plan') ||
    lower.includes("today's plan") ||
    lower.includes('what to do today')
  ) {
    return {
      text: `Good morning, Minakshi! I analyzed our latest **Google Search Console** data, **GA4 organic traffic**, **4 competitor movements** (CHEQ, AppsFlyer, DoubleVerify), and our **Master Task Library (ALL SEO Tasks)**.

Here is your prioritized **Top 3 Action Plan** for today:

---

### 🔴 1. HIGH PRIORITY: Meta Ads Fraud Detection & Invalid Clicks
- **Why:** GSC impressions dropped **28%** over 28 days (42.3k → 30.4k) and position fell from 7.4 to 12.8. Competitor CHEQ published a study claiming 19.4% invalid traffic in Advantage+ campaigns.
- **AI Action:** Content Refresh + 5 AEO Direct Answer Blocks + Entity Benchmarks + 3 Contextual Internal Links.

---

### 🟠 2. CONTENT DISTRIBUTION: Mobile App Install Fraud (Fintech & Gaming)
- **Why:** Existing article ranks #6 on Google for high-volume technical queries (8,400 monthly impressions). Topic is visual and primed for executive social amplification.
- **AI Action:** Generate 7-Slide LinkedIn Carousel + Quora High-Intent Answer with direct destination links.

---

### 🟡 3. CONTENT GAP: Google Performance Max (PMax) Bot Lead Invalidation
- **Why:** Search queries for "pmax click fraud" surged **+140%** QoQ. Current page sits at Pos 14.8 with an outdated generic guide.
- **AI Action:** Expand asset group placement teardown + offline conversion API hygiene recommendations.

---

Would you like me to execute **Meta Ads Refresh**, generate the **LinkedIn Carousel**, or do you want me to proceed with the entire morning queue?`,
      sourcesUsed: [
        'Google Search Console (28-day impression drop -28%)',
        'Google Analytics 4 (34,820 monthly organic clicks)',
        'Competitor Radar (CHEQ Advantage+ study)',
        'ALL SEO Tasks(Minakshi).csv Master Task Library',
        'mFilterIt Media Trust Knowledge Base'
      ],
      actionType: 'EXECUTE_TASK',
      targetTaskId: 'task-1',
      targetTask: tasks[0],
      followUpSuggestions: [
        'Execute Meta Ads Blog Refresh',
        'Create LinkedIn Carousel for App Fraud',
        'What did competitors publish this week?'
      ]
    };
  }

  // 2. Continuity: "Do it" / "Execute it" / "Proceed" / "Go ahead"
  if (
    lower === 'do it' || 
    lower === 'execute it' || 
    lower === 'proceed' || 
    lower === 'go ahead' ||
    lower.startsWith('do it')
  ) {
    // Check previous message context to see what was recommended
    const lastAssistantMessage = [...history].reverse().find(h => h.sender === 'assistant');
    const refersToMeta = lastAssistantMessage?.text.toLowerCase().includes('meta ads') || false;
    const refersToCarousel = lastAssistantMessage?.text.toLowerCase().includes('carousel') || false;

    if (refersToCarousel) {
      return {
        text: `Executing now based on your approved working context! 

I have activated the **Canva Creative Director Workflow** for the **Meta Ads / App Fraud LinkedIn Carousel**:
- **Format:** 1080 × 1080 LinkedIn Document PDF
- **Color Palette:** Deep Purple (#2D0C57) & Primary Purple (#531199) with white typography
- **Structure:** 7 narrative slides (Hook, Problem, Why, 4 Red Flags, Financial Cost, Marketer Action, CTA)
- **Status:** All 7 slides drafted and ready for your one-click approval before Canva rendering.`,
        sourcesUsed: [
          'Working Memory (Active Carousel Session)',
          'mFilterIt Brand Guidelines 2026 (1080x1080 specification)',
          'mFilterIt Media Trust Knowledge Base'
        ],
        actionType: 'CREATE_CAROUSEL',
        targetTaskId: 'task-1',
        targetTask: tasks[0],
        followUpSuggestions: [
          'Open Carousel Slide Approval',
          'Make it more B2B focused',
          'Generate UTM tracking links'
        ]
      };
    }

    return {
      text: `Understood! Executing the **Meta Ads Click Fraud Refresh & Multi-Channel Optimization** immediately.

Here is what I have assembled from our persistent knowledge base:
1. **Existing URL Identified:** \`https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/\` (18 months domain search equity).
2. **GSC Decay Reconciliation:** Added modern 2026 Advantage+ bot vector teardown (headless browser event spoofing).
3. **AEO Answer Blocks:** Prepared 3 modular 45-word direct answer blocks for Featured Snippet capture.
4. **Internal Linking:** Linked to \`/ad-traffic-validation/\` and \`/blog/click-fraud-in-google-ads/\`.
5. **GEO Citations:** Injected 2026 Ad Fraud Benchmark statistical table for Perplexity and Gemini.

Click below to review the interactive step-by-step output and give final human sign-off!`,
      sourcesUsed: [
        'Google Search Console (Position 12.8 recovery target)',
        'mFilterIt Website Knowledge Graph (/blog/meta-ads-click-fraud-detection/)',
        'Working Memory (Task-1 Context)',
        'Master Task Library (LIB-SEO-01)'
      ],
      actionType: 'EXECUTE_TASK',
      targetTaskId: 'task-1',
      targetTask: tasks[0],
      followUpSuggestions: [
        'Open Step-by-Step Execution Wizard',
        'Make it more B2B tone',
        'Create LinkedIn Carousel'
      ]
    };
  }

  // 3. Continuity: "Make it better" / "Revise it" / "Improve tone"
  if (
    lower.includes('make it better') || 
    lower.includes('revise it') || 
    lower.includes('improve tone') ||
    lower.includes('rewrite it')
  ) {
    return {
      text: `I revised the drafted copy to match mFilterIt's **Authoritative Enterprise B2B Voice**, cutting marketing fluff and sharpening the bottom-line ROAS impact:

### Revised Lead Narrative:
> *"In modern performance marketing ecosystems, sophisticated invalid traffic (SIVT) circumvents standard platform filters through rotating mobile residential proxies and headless browser emulation. When automated bot rings siphon 20%+ of your Meta Advantage+ budget into non-human micro-conversions, your Customer Acquisition Cost (CAC) calculations become fundamentally distorted. mFilterIt provides independent, MRC-aligned verification that reconciles media spend, cleanses retargeting data pools, and restores reporting integrity to the executive board."*

### Key Improvements Made:
- **Reduced Fluff:** Cut 38 generic introductory words.
- **Elevated Stakes:** Explicitly framed the financial danger of CAC distortion for board reporting.
- **Brand Alignment:** Positioned mFilterIt's core capability (independent verification vs black-box platform metrics).

Would you like me to apply this to the live blog draft or adjust further?`,
      sourcesUsed: [
        'mFilterIt Brand Voice Guidelines (Authoritative B2B)',
        'mFilterIt Three Trust Pillars (Media Trust)',
        'Working Memory (Previous Draft Output)'
      ],
      actionType: 'EXECUTE_TASK',
      targetTaskId: 'task-1',
      targetTask: tasks[0],
      followUpSuggestions: [
        'Accept & Apply to Draft',
        'Make it shorter and more conversational',
        'Proceed to Internal Linking'
      ]
    };
  }

  // 4. Continuity: "Use same style" / "Use approved style"
  if (
    lower.includes('use same style') || 
    lower.includes('same carousel style') || 
    lower.includes('approved style')
  ) {
    return {
      text: `Retrieved our **Previously Approved Creative Style Tokens** from Brand Memory:

- **Typography & Layout:** Minimalist B2B SaaS layout with strong left-aligned headline and split-screen illustrative diagram.
- **Color Codes:** Primary Deep Purple (\`#2D0C57\`), Primary Purple (\`#531199\`), White text, subtle Magenta Purple (\`#971199\`) accent pills.
- **Slide Dimensions:** 1080 × 1080 px (Square LinkedIn Document standard).
- **Text Density:** Maximum 35 words per slide with 3 high-contrast bullet points.
- **CTA Rule:** Direct audit link to \`/ad-traffic-validation/\`.

I will automatically apply this exact design blueprint to all upcoming carousel and infographic generations!`,
      sourcesUsed: [
        'Permanent Brand Knowledge (mFilterIt Design System)',
        'Approved Creative Vault (Meta Ads Carousel Q3)',
        'Brand Guidelines 2026'
      ],
      actionType: 'VIEW_MEMORY',
      followUpSuggestions: [
        'Generate Carousel in this Style',
        'Create Infographic in this Style',
        'View Brand Memory Center'
      ]
    };
  }

  // 5. Continuity: "Continue yesterday's work" / "Continue Meta Ads"
  if (
    lower.includes("continue yesterday") || 
    lower.includes("continue meta ads") ||
    lower.includes("where we left off")
  ) {
    return {
      text: `Retrieving our working session from yesterday (Task-1: Meta Ads Click Fraud Refresh):

### Current State in Working Memory:
1. **Content Refresh:** Drafted 1,400 words with Advantage+ bot vectors. (Status: Approved by Minakshi).
2. **AEO Answer Blocks:** 3 definition blocks generated. (Status: Approved).
3. **Internal Links:** 3 links mapped to \`/ad-traffic-validation/\` and \`/blog/click-fraud-in-google-ads/\`. (Status: Pending Insertion).
4. **LinkedIn Carousel:** 7-slide B2B narrative prepared. (Status: Ready for Canva packaging).

We can immediately proceed with **Internal Link insertion** or push the **LinkedIn Carousel to Canva**. What would you like to tackle first?`,
      sourcesUsed: [
        'Working Memory (Session Sep 29 / Sep 30)',
        'Audit Log (task-1 active state)',
        'Master Task Library'
      ],
      actionType: 'EXECUTE_TASK',
      targetTaskId: 'task-1',
      targetTask: tasks[0],
      followUpSuggestions: [
        'Open Step-by-Step Execution Wizard',
        'Send Carousel to Canva Studio',
        'Review Internal Links'
      ]
    };
  }

  // 6. "Which 2 blogs should I work on today?"
  if (
    lower.includes('which 2 blogs') || 
    lower.includes('which blogs') || 
    lower.includes('which blog should i work on')
  ) {
    return {
      text: `Based on GSC 28-day trends, GA4 organic engagement, and competitor content publishing, here are the **2 highest-impact blogs** to work on today:

### 1. Meta Ads Click Fraud Detection & Advantage+ Optimization
- **Signal:** GSC impressions dropped 28% (42,300 → 30,450); avg position slipped from 7.4 to 12.8.
- **Competitor Pressure:** CHEQ published a fresh 2,200-word Advantage+ bot study yesterday.
- **Diagnosis:** Asset has 18 months of domain search equity; refreshing is 3x faster than creating a new URL.
- **Recommended Action:** Refresh content + add 5 AEO modular answer blocks + inject 3 internal links + LinkedIn carousel.

### 2. Mobile App Install Fraud Prevention (Fintech & Gaming)
- **Signal:** 8,400 monthly impressions on question queries, but CTR is only 1.8% because competitor Adjust holds the featured snippet.
- **Diagnosis:** Comprehensive article (2,400 words) but lacks modular 45-word definition blocks and JSON-LD FAQ schema.
- **Recommended Action:** Deploy 3 direct answer definition blocks (Device Spoofing vs SDK Spoofing) + FAQ schema.

Both tasks have draft packages prepared and are awaiting your review!`,
      sourcesUsed: [
        'Google Search Console (28-day impression analysis)',
        'Google Analytics 4 (landing page dwell time)',
        'Competitor Radar (CHEQ & Adjust Featured Snippet)',
        'mFilterIt Website Knowledge Graph'
      ],
      actionType: 'EXECUTE_TASK',
      targetTaskId: 'task-1',
      targetTask: tasks[0],
      followUpSuggestions: [
        'Execute Blog 1 (Meta Ads)',
        'Execute Blog 2 (App Fraud)',
        'View Content Intelligence Matrix'
      ]
    };
  }

  // 7. "What did competitors publish this week?"
  if (
    lower.includes('competitor') || 
    lower.includes('publish this week') || 
    lower.includes('competitors')
  ) {
    return {
      text: `Here is the real-time **Competitor Intelligence Radar** for this week:

1. **CHEQ (Yesterday):** Published *"The Hidden Cost of Invalid Traffic on Meta Advantage+ Shopping Campaigns"* (2,200 words).
   - **Relevance:** Direct competitive pressure on our Meta Ads solution.
   - **AI Strategic Advice:** **Do NOT write a duplicate blog.** Refresh our existing Meta Ads article with 2026 bot benchmarks and publish a LinkedIn carousel.

2. **AppsFlyer Protect360 (3 days ago):** Updated annual *"State of Mobile App Install Fraud 2026"* benchmark report.
   - **Relevance:** AppsFlyer currently captures 72% of Perplexity and Gemini citations for app fraud benchmarks.
   - **AI Strategic Advice:** Enrich our Mobile App Fraud landing page with unique biometric entity definitions to recapture GEO search visibility.

3. **DoubleVerify (5 days ago):** Launched *"Retail Media Network Brand Safety Verification"*.
   - **Relevance:** Retail media is surging across Amazon and Noon.
   - **AI Strategic Advice:** Add a dedicated Retail Media section to our eCommerce brand safety pillar page.

4. **HUMAN Security (1 week ago):** Capturing top 3 rankings for *"fake lead detection in performance marketing"*.
   - **AI Strategic Advice:** Add direct answer FAQ blocks to our PMax Click Fraud article.`,
      sourcesUsed: [
        'Competitor Radar Crawler (CHEQ, AppsFlyer, DoubleVerify, HUMAN)',
        'Perplexity & Generative Search Monitor',
        'mFilterIt Three Trust Pillars (Media Trust & Brand Trust)'
      ],
      actionType: 'EXECUTE_TASK',
      targetTaskId: 'task-1',
      targetTask: tasks[0],
      followUpSuggestions: [
        'Execute Counter-Strategy for CHEQ',
        'Enrich App Fraud Page for AppsFlyer Gap',
        'View Full Competitor Radar'
      ]
    };
  }

  // 8. "Create a LinkedIn Carousel" / "Canva"
  if (
    lower.includes('carousel') || 
    lower.includes('linkedin carousel') || 
    lower.includes('canva')
  ) {
    return {
      text: `I have prepared a structured **7-Slide B2B LinkedIn Carousel** based on our approved Meta Ads research:

- **Slide 1 (Hook):** *"Your Meta Ads ROAS Is Lying To You (Here Is Why)"*
- **Slide 2 (Problem):** *"The Advantage+ Black Box: How Bots Poison Algorithmic Bidding"*
- **Slide 3 (Why it happens):** *"Why Standard IP Filters Fail Against 5G Residential Proxies"*
- **Slide 4 (Key Signals):** *"4 Red Flags in Your Meta Ads Manager & GA4"*
- **Slide 5 (Impact):** *"The Financial Reality: Distorted CAC & Sales Team Fatigue"*
- **Slide 6 (What Marketers Do):** *"3 Steps to Cleanse Offline Conversion APIs & Block SIVT"*
- **Slide 7 (CTA):** *"Stop Paying For Bot Clicks. Audit Your Meta Ads Free."*

You can review, edit any individual slide, approve all slides, and trigger the Canva layout package!`,
      sourcesUsed: [
        'mFilterIt Media Trust Knowledge Base',
        'Approved Meta Ads Refresh Draft',
        'Canva Creative Director Guidelines (1080x1080 standard)'
      ],
      actionType: 'CREATE_CAROUSEL',
      targetTaskId: 'task-1',
      targetTask: tasks[0],
      followUpSuggestions: [
        'Open Carousel Slide Approval',
        'Customize CTA copy',
        'Make Slide 1 Hook bolder'
      ]
    };
  }

  // 9. "Content Distribution Links"
  if (lower.includes('distribution link') || lower.includes('content link') || lower.includes('destination link')) {
    return {
      text: `Here are the active destination links for multi-channel distribution across our content assets:

1. **LinkedIn Carousel:**
   \`https://www.mfilterit.com/ad-traffic-validation/\`

2. **Quora Answer:**
   \`https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/\`

3. **Reddit Community Discussion:**
   \`https://www.mfilterit.com/blog/google-performance-max-fraud-prevention/\`

4. **Pinterest Infographic:**
   \`https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/\``,
      sourcesUsed: [
        'Content Distribution Agent',
        'mFilterIt Website Knowledge Graph'
      ],
      actionType: 'GENERAL',
      followUpSuggestions: [
        'Open Carousel Builder',
        'Check Distribution Channels',
        'View Content Assets'
      ]
    };
  }

  // 10. "AEO" / "Answer Engine Optimization"
  if (lower.includes('aeo') || lower.includes('answer engine') || lower.includes('featured snippet')) {
    return {
      text: `Current **AEO (Answer Engine Optimization) Audit** for mFilterIt:

- **Featured Snippet Opportunities Identified:** 3 in striking distance (position 2–6).
- **People Also Ask (PAA) Gap:** Competitors capture 41% of definitions in PAA boxes because our pages historically used dense narrative prose rather than 40–50 word modular answer blocks.
- **Top Priority Question to Win:**
  > *"How do fraudsters fake Meta Advantage+ conversions?"*
  > **Recommended 48-word Answer:** *"Fraudsters fake Meta Advantage+ conversions using automated headless browsers that trigger synthetic Add-to-Cart and Lead events, tricking Meta algorithmic machine learning into allocating ad budget toward bot-infested placements rather than genuine buyers."*

Deploying this direct answer block alongside JSON-LD FAQ schema will recapture the snippet from CHEQ.`,
      sourcesUsed: [
        'Google Search Console Question Query Reports',
        'Google SERP PAA Analysis',
        'mFilterIt AEO Knowledge Base',
        'Schema.org FAQPage Validator'
      ],
      actionType: 'OPTIMIZE_AEO',
      targetTaskId: 'task-2',
      targetTask: tasks[1],
      followUpSuggestions: [
        'Inject AEO Answer Block',
        'Copy JSON-LD Schema Code',
        'View all 3 AEO Opportunities'
      ]
    };
  }

  // 11. "AI Search Visibility" / "Perplexity Citations" / "ChatGPT"
  if (lower.includes('perplexity') || lower.includes('chatgpt') || lower.includes('ai search') || lower.includes('citation')) {
    return {
      text: `Current **AI Search & Engine Citation Audit** for mFilterIt:

- **Perplexity & Google AI Overviews Citation Share:**
  - DoubleVerify & CHEQ cited in **83%** of enterprise queries.
  - mFilterIt cited in **18%** of queries.
- **Why the Gap Exists:** LLMs synthesize answers using structured statistical benchmark tables, numeric percentage callouts, and Schema.org Product markup with \`sameAs\` authority links.
- **AI Action Plan:** Inject verified **"2026 Ad Fraud Benchmark Data"** tabular statistics into \`/ad-traffic-validation/\` to increase citation frequency from 18% to over 60%.`,
      sourcesUsed: [
        'Perplexity AI Citation Audit',
        'Google AI Overviews Tracking',
        'Competitor Benchmark Analysis',
        'mFilterIt Product Knowledge Graph'
      ],
      actionType: 'EXECUTE_TASK',
      targetTaskId: 'task-3',
      targetTask: tasks[2],
      followUpSuggestions: [
        'Execute Citation Data Injection',
        'View Perplexity Citation Gap',
        'Inspect Schema Entity Triples'
      ]
    };
  }

  // 12. "Three trust pillars" / "Products" / "What does mfilterit do"
  if (
    lower.includes('trust pillar') || 
    lower.includes('pillars') || 
    lower.includes('what does mfilterit do') ||
    lower.includes('products')
  ) {
    const pillars = MFILTERIT_MASTER_KNOWLEDGE.threeTrustPillars;
    return {
      text: `mFilterIt's business architecture is anchored around **Three Core Trust Pillars**:

### 1. MEDIA TRUST (Ad Spend & Traffic Integrity)
- **Problem Solved:** Siphoning of digital ad spend across Google, Meta, Programmatic, and Affiliate campaigns by invalid traffic (IVT) and bot networks.
- **Key Solutions:** Full Funnel Ad Traffic Validation, Mobile App Install Fraud Prevention, Affiliate Fraud Detection, Brand Safety Placement Verification.
- **Key Competitors:** DoubleVerify, CHEQ, AppsFlyer Protect360, HUMAN Security.

### 2. BRAND TRUST (Marketplace & Digital Brand Protection)
- **Problem Solved:** Counterfeit products, unauthorized gray-market sellers, MAP price violations, and brand infringement across Amazon, Flipkart, Noon, Shopee.
- **Key Solutions:** eCommerce Brand Infringement Monitoring, Marketplace Buy-Box Protection, Domain Typosquatting & Phishing Takedown.
- **Key Competitors:** Red Points, Corsearch, BrandShield.

### 3. FINANCIAL TRUST (Scam Protection & Transaction Integrity)
- **Problem Solved:** Direct Carrier Billing (DCB) malware, silent OTP hijacking, rogue banking APKs, and social media support impersonation scams.
- **Key Solutions:** DCB Fraud Detection for Telcos, Mobile Banking Scam Threat Feeds.

All content, SEO strategies, and campaign assets automatically align with one of these three pillars!`,
      sourcesUsed: [
        'mFilterIt Master Knowledge Base (Three Trust Pillars)',
        'mfilterit.com Product Registry',
        'Brand Guidelines 2026'
      ],
      actionType: 'VIEW_MEMORY',
      followUpSuggestions: [
        'Explore Media Trust Solutions',
        'Explore Brand Trust eCommerce Monitoring',
        'View Memory Center'
      ]
    };
  }

  // 13. General Contextual Query
  return {
    text: `I have analyzed your query across **mFilterIt's Master Knowledge Base**, active Search Console impression trends, GA4 organic engagement, and our competitor radar.

### Key Contextual Observations:
- **Media Trust Alignment:** Active focus is on recovering organic visibility for Meta Ads click fraud detection while countering CHEQ's recent Advantage+ report.
- **Search Synergy:** Injecting modular 45-word answers and verified numerical benchmarks provides immediate dual benefit for both Google Featured Snippets and AI search engine citations.
- **Execution Efficiency:** We have 4 pre-assembled task cards in your queue ready for one-click review and deployment.

How would you like to proceed? I can draft content refreshes, create visual carousels, or assist with direct answer optimization.`,
    sourcesUsed: [
      'mFilterIt Master Knowledge Base (3 Trust Pillars)',
      'Google Search Console (412,800 monthly impressions)',
      'Google Analytics 4 (3m 48s avg dwell time)',
      'Competitor Intelligence Radar'
    ],
    actionType: 'GENERAL',
    followUpSuggestions: [
      'What should I do today?',
      'Which 2 blogs should I work on today?',
      'Create LinkedIn Carousel'
    ]
  };
}
