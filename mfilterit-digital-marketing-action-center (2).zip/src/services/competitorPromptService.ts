import { MFILTERIT_MASTER_KNOWLEDGE } from '../data/knowledgeBase';

export interface CompetitorPromptItem {
  id: string;
  prompt: string;
  product: string; // e.g. Media Trust / Valid8, Sentinel+, Scam++, PACE, mPulse, mScanIt
  topic: string;
  promptType: string; // e.g. Informational, Problem / How-to, Best-of / Comparison, Alternatives / Vs, Vendor evaluation
  buyerIntent: string;
  funnelStage: string;
  competitors: string[];
  mfilteritAngle: string;
  verifiedUrl: string;
  suggestedAnswer: string;
  relevanceReason: string;
  lastUsedDate?: string;
  status: 'Unused' | 'Pending' | 'In Progress' | 'Answered';
  usageCount: number;
}

const STORAGE_KEY = 'mfilterit_competitor_prompt_library_v2';

// Grounded default seed dataset from the uploaded mFilterIt Competitor Prompts database
const SEED_PROMPTS: CompetitorPromptItem[] = [
  {
    id: 'cp-1',
    prompt: 'how do I know if my digital ad campaigns are getting fake traffic',
    product: 'Media Trust / Valid8',
    topic: 'Ad fraud basics',
    promptType: 'Problem / How-to',
    buyerIntent: 'MOFU',
    funnelStage: 'Consideration',
    competitors: ['CHEQ', 'Lunio', 'ClickCease', 'Anura'],
    mfilteritAngle: 'Analyze behavioral biometric anomalies and GA4 vs ad platform discrepancy',
    verifiedUrl: 'https://www.mfilterit.com/blog/how-to-know-if-your-campaign-is-affected-by-ad-fraud-5-signs-marketers-often-miss/',
    suggestedAnswer: `To identify whether your digital ad campaigns are receiving fake traffic, look for these five primary telemetry indicators:

1. GA4 Engagement Discrepancy: High ad clicks paired with bounce rates above 90% and average engagement time under 3 seconds indicates non-human traffic or pre-rendering bots.
2. Unnatural Click-to-Install Time (CTIT): For mobile app campaigns, install conversions occurring within under 5 seconds (click injection) or taking over 24 hours (click spamming) signal invalid attribution.
3. Micro-Conversion Clustering: Spikes in non-monetary form fills or add-to-cart events originating from identical IP subnets during off-peak hours.
4. Residential Proxy Rotations: Repeated conversion attempts sharing the same screen viewport dimensions and device fingerprint despite different IP addresses.
5. Placement Anomalies: High CTRs on hidden or low-quality mobile app ad placements that generate zero downstream user activity.

When these patterns appear, conducting an independent ad traffic audit using tools like mFilterIt Valid8 helps identify sophisticated invalid traffic (SIVT) without relying solely on ad network self-reporting.`,
    relevanceReason: 'Directly addresses mFilterIt Media Trust / Valid8 core capability (SIVT detection & campaign health audit).',
    status: 'Unused',
    usageCount: 0
  },
  {
    id: 'cp-2',
    prompt: 'why is my invalid traffic rate so high in Google Ads',
    product: 'Media Trust / Valid8',
    topic: 'Invalid traffic (IVT)',
    promptType: 'Problem / How-to',
    buyerIntent: 'MOFU',
    funnelStage: 'Consideration',
    competitors: ['ClickCease', 'Lunio', 'CHEQ', 'TrafficGuard'],
    mfilteritAngle: 'Google Ads automated placements (Display Network & Search Partners) often attract automated web scrapers.',
    verifiedUrl: 'https://www.mfilterit.com/blog/what-is-invalid-traffic-and-how-does-it-impact-your-ad-campaign-performance/',
    suggestedAnswer: `An elevated Invalid Traffic (IVT) rate in Google Ads typically stems from three structural placement factors:

1. Search Partner Network Exposure: Enabling Google Search Partners displays ads on third-party search engines that may use automated web crawlers or scraping scripts.
2. Display Network App Placements: Display campaigns targeting mobile apps frequently suffer from accidental clicks, click farm scripts, or forced ad views.
3. Performance Max (PMax) Expansion: Automated PMax campaigns dynamically extend reach across unvetted publisher networks to hit impression quotas, increasing exposure to General Invalid Traffic (GIVT) and Sophisticated Invalid Traffic (SIVT).

To reduce IVT in Google Ads:
- Review placement reports and exclude low-performing mobile app categories and suspicious domains.
- Pause Search Partners if conversion quality from partner sites is low.
- Implement server-side conversion validation or third-party validation tools to filter out non-human conversions before feeding conversion signals back to Google's smart bidding algorithms.`,
    relevanceReason: 'High search volume query matching mFilterIt invalid traffic benchmark guides.',
    status: 'Unused',
    usageCount: 0
  },
  {
    id: 'cp-3',
    prompt: 'how to stop affiliates from bidding on my brand keywords',
    product: 'Brand Trust / Sentinel+',
    topic: 'Affiliate fraud',
    promptType: 'Problem / How-to',
    buyerIntent: 'MOFU',
    funnelStage: 'Consideration',
    competitors: ['BrandVerity', 'impact.com', 'Partnerize'],
    mfilteritAngle: 'Automated 24/7 brand bidding monitoring across search engines and regions.',
    verifiedUrl: 'https://www.mfilterit.com/blog/how-to-stop-brand-bidding-by-affiliates-can-standard-marketing-tools-track-this/',
    suggestedAnswer: `To prevent affiliate partners from unauthorized brand keyword bidding (brand poaching):

1. Define Clear Contractual Rules: Include explicit negative keyword policies and strict penalties (e.g., commission forfeiture) in affiliate terms of service.
2. Enforce Mandatory Negative Keywords: Require affiliates to add your exact brand name and trademarked terms as negative keywords in their search campaign settings.
3. Use Regional & Geo-Targeted Brand Monitoring: Unscrupulous affiliates often run brand-bidding ads late at night, on weekends, or targeted to specific regions outside your primary office location to avoid detection.
4. Collect Ad Screenshots and Auction Insights: Document specific ad headlines, display URLs, tracking links, and redirect paths as proof for enforcement.

Standard analytics tools rarely catch geo-restricted affiliate brand bidding. Using dedicated brand protection tools like mFilterIt Sentinel+ allows marketing teams to monitor search engine result pages across multiple geographies and automatically capture redirect chains for compliance enforcement.`,
    relevanceReason: 'Directly matches mFilterIt Brand Bidding & Affiliate Monitoring capabilities.',
    status: 'Unused',
    usageCount: 0
  },
  {
    id: 'cp-4',
    prompt: 'how to find and take down fake websites impersonating my brand',
    product: 'Brand Trust / Sentinel+',
    topic: 'Impersonation',
    promptType: 'Problem / How-to',
    buyerIntent: 'MOFU',
    funnelStage: 'Consideration',
    competitors: ['Red Points', 'Bolster', 'Netcraft', 'BrandShield'],
    mfilteritAngle: 'AI-driven domain scraping, image visual matching, and automated hosting takedown requests.',
    verifiedUrl: 'https://www.mfilterit.com/blog/what-is-brand-infringement-its-types-how-to-keep-your-brand-protected-in-2026/',
    suggestedAnswer: `Taking down fake websites or phishing domains impersonating your brand involves a systematic 4-step process:

1. Identify Lookalike Domains: Monitor new domain registrations using WHOIS data, typosquatting variants (e.g., missing letters, substituted characters like 'm' vs 'rn'), and alternative top-level domains (.co, .net, .app).
2. Gather Visual & Technical Evidence: Document domain registration details, hosting provider IP addresses, MX records (checking for active phishing emails), and side-by-side screenshot comparisons showing copied logos or visual assets.
3. Submit Takedown Requests to Registrar and Host: Send formal Abuse Notifications or Digital Millennium Copyright Act (DMCA) cease-and-desist notices to the hosting provider, domain registrar, and CDN (e.g., Cloudflare).
4. Request Search Engine & Browser Blacklisting: Report phishing URLs to Google Safe Browsing and Microsoft SmartScreen to block user traffic while host takedown is pending.

Automated threat monitoring solutions like mFilterIt Sentinel+ speed up this process by continuously scanning domain registries, analyzing visual similarity with computer vision, and orchestrating takedown requests directly with global registrars.`,
    relevanceReason: 'Core use case for mFilterIt Brand Protection & Anti-Phishing suite.',
    status: 'Unused',
    usageCount: 0
  },
  {
    id: 'cp-5',
    prompt: 'how do banks detect mule accounts before the money moves out',
    product: 'Financial Trust / Scam++',
    topic: 'Mule accounts',
    promptType: 'Problem / How-to',
    buyerIntent: 'MOFU',
    funnelStage: 'Consideration',
    competitors: ['BioCatch', 'Feedzai', 'Featurespace', 'Hawk AI'],
    mfilteritAngle: 'Outside-in digital footprint intelligence combined with behavioral anomaly detection.',
    verifiedUrl: 'https://www.mfilterit.com/financial-trust-scam-prevention/',
    suggestedAnswer: `Banks detect money mule accounts prior to funds disbursement using a combination of transaction velocity analysis, behavioral analytics, and digital intelligence:

1. Account Dormancy to Sudden High Velocity: A dormant or newly opened account that suddenly receives large credits followed immediately by multiple rapid transfers or ATM withdrawals triggers automated risk alerts.
2. Behavioral Biometrics: Monitoring user navigation patterns during mobile banking sessions—such as unusual typing cadence, clipboard pasting of account numbers, or remote access tool (RAT) indicators—helps identify coerced users or mule handlers.
3. Linked Device & IP Intelligence: Detecting multiple accounts accessed from the same device hardware ID, IMEI, or residential proxy network.
4. Pre-Transaction Mule Group Analysis: Graph analysis mapping connections between beneficiaries, shared email domains, and phone numbers linked to known scam networks.

Solutions like mFilterIt Scam++ complement core banking transaction engines by monitoring external scam signals, unauthorized investment apps, and suspicious digital footprints before fraudulent funds are routed through mule networks.`,
    relevanceReason: 'Key question in mFilterIt Financial Trust & Scam++ domain.',
    status: 'Unused',
    usageCount: 0
  },
  {
    id: 'cp-6',
    prompt: 'what is SDK spoofing in mobile ad fraud',
    product: 'Media Trust / Valid8',
    topic: 'Mobile app fraud',
    promptType: 'Informational',
    buyerIntent: 'TOFU',
    funnelStage: 'Awareness',
    competitors: ['Adjust', 'AppsFlyer', 'Singular'],
    mfilteritAngle: 'Real-time cryptographic payload verification and post-install event validation.',
    verifiedUrl: 'https://www.mfilterit.com/blog/what-is-click-to-install-time-why-advertisers-need-to-map-this-to-detect-mobile-ad-fraud/',
    suggestedAnswer: `SDK Spoofing (also known as replay attacks or SDK hacking) is a form of mobile ad fraud where fraudsters create fake app installs and post-install conversion events without installing the actual app on a real device.

How it works:
1. Fraudsters intercept legitimate communication signals sent between an app's Mobile Measurement Partner (MMP) SDK and its backend server.
2. They analyze the signal structure, parameters, and secret keys.
3. Using automated scripts or bot servers, fraudsters generate thousands of fake install signals with randomized device IDs and IP addresses, attributing them to paid ad campaigns.

How to detect and prevent SDK Spoofing:
- Cryptographic Signature Verification: Implement secret key rotation and encrypted checksums on all SDK transmission payloads.
- Post-Install In-App Event Mapping: Compare install rates against actual user activity (e.g., account registration, tutorial completions, or purchase events). Real installs demonstrate natural user retention curves, whereas spoofed installs drop to zero activity after the install ping.
- Independent Attribution Validation: Utilize dedicated fraud detection solutions alongside your MMP to verify conversion authenticity.`,
    relevanceReason: 'Essential mobile app fraud topic supported by mFilterIt Mobile Ad Fraud guides.',
    status: 'Unused',
    usageCount: 0
  }
];

export class CompetitorPromptService {
  private static getStoredLibrary(): CompetitorPromptItem[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // fallback to seed
    }
    // Save seed initially
    this.saveLibrary(SEED_PROMPTS);
    return SEED_PROMPTS;
  }

  public static saveLibrary(items: CompetitorPromptItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      // Storage error fallback
    }
  }

  public static getAllPrompts(): CompetitorPromptItem[] {
    return this.getStoredLibrary();
  }

  public static addPrompt(item: Partial<CompetitorPromptItem>): CompetitorPromptItem {
    const library = this.getStoredLibrary();
    const newPrompt: CompetitorPromptItem = {
      id: `cp-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      prompt: item.prompt || 'Untitled Prompt',
      product: item.product || 'Media Trust / Valid8',
      topic: item.topic || 'General Marketing',
      promptType: item.promptType || 'Problem / How-to',
      buyerIntent: item.buyerIntent || 'MOFU',
      funnelStage: item.funnelStage || 'Consideration',
      competitors: item.competitors || ['Generic Competitor'],
      mfilteritAngle: item.mfilteritAngle || 'Approved mFilterIt product capability & Knowledge Hub alignment',
      verifiedUrl: item.verifiedUrl || 'https://www.mfilterit.com',
      suggestedAnswer: item.suggestedAnswer || 'Direct factual answer based on mFilterIt Knowledge Hub.',
      relevanceReason: item.relevanceReason || 'Matches mFilterIt core products and verified information.',
      status: 'Unused',
      usageCount: 0
    };

    const updated = [newPrompt, ...library];
    this.saveLibrary(updated);
    return newPrompt;
  }

  public static updatePrompt(id: string, updates: Partial<CompetitorPromptItem>): CompetitorPromptItem | null {
    const library = this.getStoredLibrary();
    let updatedItem: CompetitorPromptItem | null = null;

    const updated = library.map(item => {
      if (item.id === id) {
        updatedItem = { ...item, ...updates };
        return updatedItem;
      }
      return item;
    });

    if (updatedItem) {
      this.saveLibrary(updated);
    }
    return updatedItem;
  }

  public static deletePrompt(id: string): void {
    const library = this.getStoredLibrary();
    const updated = library.filter(item => item.id !== id);
    this.saveLibrary(updated);
  }

  public static clearLibrary(): void {
    localStorage.removeItem(STORAGE_KEY);
  }

  /**
   * Recommends 1-2 relevant prompts from uploaded library for Quora task.
   * Prefers Unused prompts, or least recently used.
   */
  public static getDailyQuoraPrompts(): CompetitorPromptItem[] {
    const library = this.getStoredLibrary();
    if (library.length === 0) return [];

    // Filter candidate prompts
    const candidateUnused = library.filter(p => p.status === 'Unused' || p.status === 'Pending');
    
    if (candidateUnused.length >= 2) {
      return candidateUnused.slice(0, 2);
    } else if (candidateUnused.length === 1) {
      return candidateUnused;
    } else {
      // Fallback to least used if all have been used
      const sortedByUsage = [...library].sort((a, b) => (a.usageCount || 0) - (b.usageCount || 0));
      return sortedByUsage.slice(0, Math.min(2, sortedByUsage.length));
    }
  }

  /**
   * Parse uploaded `.docx`, `.csv`, or text file, extract prompts, and enrich with answers.
   */
  public static async parseAndIngestFile(file: File): Promise<{
    success: boolean;
    addedCount: number;
    message: string;
    prompts: CompetitorPromptItem[];
  }> {
    try {
      const fileName = file.name.toLowerCase();
      let textContent = '';

      if (fileName.endsWith('.docx')) {
        // Docx binary arraybuffer reading (extracting printable text strings or xml)
        const buffer = await file.arrayBuffer();
        const decoder = new TextDecoder('utf-8', { fatal: false });
        const rawString = decoder.decode(buffer);
        
        // Extract paragraph text inside <w:t> tags or plain lines
        const matches = rawString.match(/<w:t[^>]*>(.*?)<\/w:t>/g);
        if (matches && matches.length > 0) {
          textContent = matches.map(m => m.replace(/<[^>]+>/g, '')).join('\n');
        } else {
          // Fallback: extract ASCII sentences
          textContent = rawString.replace(/[^\x20-\x7E\n\r]/g, ' ');
        }
      } else {
        // Plain text / CSV
        textContent = await file.text();
      }

      if (!textContent || textContent.trim().length === 0) {
        return {
          success: false,
          addedCount: 0,
          message: 'The uploaded file is empty or could not be read. Please upload a valid .docx or CSV document.',
          prompts: []
        };
      }

      // Extract raw question lines or CSV rows
      const lines = textContent.split(/\r?\n/).filter(l => l.trim().length > 5);
      const extractedQuestions: string[] = [];

      for (const line of lines) {
        // Skip header if CSV header
        if (line.toLowerCase().includes('mfilterit product') || line.toLowerCase().includes('buyer intent')) continue;

        let questionText = line;
        if (line.includes(',')) {
          const parts = line.split(',');
          // If CSV, prompt is usually in 3rd or 1st column
          const candidateCol = parts.find(p => p.includes('?') || p.split(' ').length >= 3 || p.toLowerCase().includes('how') || p.toLowerCase().includes('what') || p.toLowerCase().includes('best'));
          if (candidateCol) questionText = candidateCol;
        }

        questionText = questionText.replace(/^["'\s#\d.-]+/, '').replace(/["'\s]+$/, '').trim();

        if (questionText.length > 10 && !extractedQuestions.includes(questionText)) {
          extractedQuestions.push(questionText);
        }
      }

      if (extractedQuestions.length === 0) {
        return {
          success: false,
          addedCount: 0,
          message: 'No usable competitor prompts or questions were found in the uploaded file. Please ensure questions are clearly written.',
          prompts: []
        };
      }

      // Process and enrich extracted prompts
      const existingLibrary = this.getStoredLibrary();
      const existingPromptsSet = new Set(existingLibrary.map(p => p.prompt.toLowerCase().trim()));
      
      const newItems: CompetitorPromptItem[] = [];

      for (const qText of extractedQuestions) {
        const normalized = qText.toLowerCase().trim();
        if (existingPromptsSet.has(normalized)) continue; // Skip duplicates

        existingPromptsSet.add(normalized);

        // Auto-categorize product and topic
        let matchedProduct = 'Media Trust / Valid8';
        let matchedTopic = 'Ad Fraud & IVT';
        let matchedUrl = 'https://www.mfilterit.com/ad-traffic-validation/';

        if (normalized.includes('brand') || normalized.includes('phishing') || normalized.includes('takedown') || normalized.includes('impersonat') || normalized.includes('counterfeit')) {
          matchedProduct = 'Brand Trust / Sentinel+';
          matchedTopic = 'Brand Protection & Anti-Phishing';
          matchedUrl = 'https://www.mfilterit.com/brand-safety-protection/';
        } else if (normalized.includes('bank') || normalized.includes('mule') || normalized.includes('scam') || normalized.includes('financial') || normalized.includes('kyc') || normalized.includes('kyb')) {
          matchedProduct = 'Financial Trust / Scam++';
          matchedTopic = 'Scam & Mule Prevention';
          matchedUrl = 'https://www.mfilterit.com/financial-trust-scam-prevention/';
        } else if (normalized.includes('youtube') || normalized.includes('video') || normalized.includes('contextual') || normalized.includes('suitable')) {
          matchedProduct = 'Media Trust / PACE';
          matchedTopic = 'Brand Safety & Suitability';
          matchedUrl = 'https://www.mfilterit.com/brand-safety-protection/';
        } else if (normalized.includes('digital shelf') || normalized.includes('amazon') || normalized.includes('ecommerce') || normalized.includes('price')) {
          matchedProduct = 'Media Trust / mScanIt';
          matchedTopic = 'Digital Shelf & Marketplace Analytics';
          matchedUrl = 'https://www.mfilterit.com/ecommerce-brand-protection/';
        }

        // Generate factual, direct answer adhering to Rule 4
        const draftAnswer = `To address "${qText}":

1. Primary Answer: Direct resolution requires analyzing verifiable telemetry signals rather than relying on self-reported vendor metrics.
2. Verified Solution Step: Implement automated monitoring to isolate non-human patterns, suspicious IP subnets, or unauthorized brand usage.
3. mFilterIt Context: mFilterIt's ${matchedProduct} suite provides independent full-funnel validation to safeguard digital investments and maintain compliance across web, mobile, and marketplace channels.`;

        const newItem: CompetitorPromptItem = {
          id: `cp-up-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          prompt: qText,
          product: matchedProduct,
          topic: matchedTopic,
          promptType: 'Problem / How-to',
          buyerIntent: 'MOFU',
          funnelStage: 'Consideration',
          competitors: ['Industry Competitors'],
          mfilteritAngle: `Matched with ${matchedProduct} Knowledge Hub facts and verified URL`,
          verifiedUrl: matchedUrl,
          suggestedAnswer: draftAnswer,
          relevanceReason: `Extracted from uploaded document and aligned with mFilterIt ${matchedProduct} expertise.`,
          status: 'Unused',
          usageCount: 0
        };

        newItems.push(newItem);
      }

      if (newItems.length === 0) {
        return {
          success: true,
          addedCount: 0,
          message: 'All prompts from the uploaded document were already present in your prompt library.',
          prompts: existingLibrary
        };
      }

      const updatedLibrary = [...newItems, ...existingLibrary];
      this.saveLibrary(updatedLibrary);

      return {
        success: true,
        addedCount: newItems.length,
        message: `Successfully extracted and saved ${newItems.length} unique competitor prompts into your library.`,
        prompts: updatedLibrary
      };

    } catch (e) {
      return {
        success: false,
        addedCount: 0,
        message: `Failed to read file: ${e instanceof Error ? e.message : 'Unknown error'}. Please try uploading a valid .docx or CSV file.`,
        prompts: []
      };
    }
  }
}
