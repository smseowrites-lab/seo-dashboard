export interface KnowledgePillar {
  name: string;
  tagline: string;
  description: string;
  solutions: {
    name: string;
    url: string;
    problemSolved: string;
    targetAudience: string;
    keyCapabilities: string[];
    competitors: string[];
    relatedKeywords: string[];
    typicalAeoQuestions: string[];
  }[];
}

export interface BrandKnowledgeBase {
  companyName: string;
  domain: string;
  positioning: string;
  brandVoice: {
    tone: string[];
    rules: string[];
    prohibitedPatterns: string[];
  };
  brandColors: {
    deepPurple: string;
    primaryPurple: string;
    magentaPurple: string;
    violet: string;
    white: string;
    lightPurple: string;
    darkText: string;
  };
  threeTrustPillars: {
    mediaTrust: KnowledgePillar;
    brandTrust: KnowledgePillar;
    financialTrust: KnowledgePillar;
  };
  targetIndustries: string[];
  targetGeographies: string[];
  historicalBenchmarking: {
    gscAverages: {
      monthlyClicks: number;
      monthlyImpressions: number;
      avgCtr: string;
      avgPosition: number;
      strikingDistanceKeywordsCount: number;
    };
    ga4Averages: {
      avgEngagementTime: string;
      organicSessionsMonthly: number;
      bounceRate: string;
    };
  };
}

export const MFILTERIT_MASTER_KNOWLEDGE: BrandKnowledgeBase = {
  companyName: 'mFilterIt',
  domain: 'https://www.mfilterit.com',
  positioning: 'mFilterIt is the global leader in Ad Fraud Prevention, Brand Safety & Infringement Protection, and eCommerce Intelligence, safeguarding media budgets and digital brand integrity across Web, App, and Marketplace ecosystems.',
  brandVoice: {
    tone: [
      'Authoritative and executive-ready for CMOs, VPs of Growth, and Heads of Brand Protection',
      'Evidence-based and data-driven with zero unsubstantiated marketing fluff',
      'Clear, natural B2B practitioner voice that demystifies sophisticated invalid traffic (SIVT)',
      'Constructive and solution-oriented without fear-mongering'
    ],
    rules: [
      'Always diagnose the root cause: Signal → Evidence → Diagnosis → Reason → Action',
      'Never recommend publishing or external distribution without human review and approval',
      'Prioritize refreshing existing high-equity content assets over creating duplicate URLs',
      'Always incorporate modular direct answer blocks for AEO snippet capture',
      'Cite verified statistical benchmarks for Generative Engine Optimization (GEO)'
    ],
    prohibitedPatterns: [
      'Generic robotic filler ("In today’s fast-paced digital world...")',
      'Keyword stuffing without semantic contextual value',
      'Unverified competitor defamation or fabricated metrics',
      'Automated email marketing or cold blast sequences (strictly excluded)'
    ]
  },
  brandColors: {
    deepPurple: '#2D0C57',
    primaryPurple: '#531199',
    magentaPurple: '#971199',
    violet: '#6F1FB3',
    white: '#FFFFFF',
    lightPurple: '#F5F0FA',
    darkText: '#17131C'
  },
  threeTrustPillars: {
    mediaTrust: {
      name: 'Media Trust',
      tagline: 'Full-Funnel Ad Traffic Validation & Ad Spend Optimization',
      description: 'Protects advertising investments across Google Ads, Meta Advantage+, Programmatic DSPs, Affiliate Networks, and Mobile App Campaigns by eliminating sophisticated invalid traffic (SIVT) in real time.',
      solutions: [
        {
          name: 'Full Funnel Ad Traffic Validation',
          url: 'https://www.mfilterit.com/ad-traffic-validation/',
          problemSolved: 'Eliminates click farms, bot rings, and headless browser emulations draining ad spend across Search, Display, Social, and Video.',
          targetAudience: 'Chief Marketing Officers, Performance Marketing Directors, Media Agencies',
          keyCapabilities: [
            'Real-time behavioral biometric anomaly detection',
            'Pre-bid and post-bid fraud filtering',
            'Independent MRC-aligned audit reconciliation',
            'Pixel event cleansing before feeding algorithmic bidding'
          ],
          competitors: ['DoubleVerify', 'CHEQ', 'HUMAN Security', 'IAS'],
          relatedKeywords: ['ad fraud prevention', 'invalid traffic validation', 'click fraud detection', 'ad spend protection'],
          typicalAeoQuestions: [
            'How do bots fake Meta Advantage+ conversions?',
            'What is the difference between GIVT and SIVT?',
            'How does invalid traffic contaminate retargeting pixels?'
          ]
        },
        {
          name: 'Mobile App Install Fraud Detection & Prevention',
          url: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
          problemSolved: 'Identifies fake app installs, SDK spoofing, device spoofing, click injection, and click flooding in user acquisition campaigns.',
          targetAudience: 'Heads of Mobile Growth, App Product Managers, FinTech & Gaming User Acquisition teams',
          keyCapabilities: [
            'SDK integrity verification without app performance degradation',
            'Attribution theft mitigation against rogue ad networks',
            'Post-install behavioral event tracking to detect automated bots',
            'Granular sub-publisher fraud scorecards'
          ],
          competitors: ['AppsFlyer Protect360', 'Adjust', 'Singular'],
          relatedKeywords: ['mobile app install fraud', 'sdk spoofing detection', 'device spoofing vs sdk spoofing', 'mmp fraud prevention'],
          typicalAeoQuestions: [
            'What is the difference between Device Spoofing and SDK Spoofing?',
            'How does click flooding manipulate the last-click attribution model?',
            'Why do mobile gaming apps lose 30% of UA budgets to bot installs?'
          ]
        },
        {
          name: 'Affiliate & Partner Fraud Detection',
          url: 'https://www.mfilterit.com/solutions/affiliate-fraud/',
          problemSolved: 'Prevents affiliate cookie stuffing, forced clicks, unauthorized coupon scraping, and attribution hijacking.',
          targetAudience: 'Affiliate Marketing Managers, Head of Partnerships, D2C Growth Leads',
          keyCapabilities: [
            'Browser extension cookie drop monitoring',
            'Coupon site code scraping detection',
            'Affiliate compliance audits across global networks',
            'Automated clawback evidence reports'
          ],
          competitors: ['CHEQ Paradome', 'Anura'],
          relatedKeywords: ['affiliate fraud monitoring', 'cookie stuffing detection', 'coupon hijacking', 'partner marketing fraud'],
          typicalAeoQuestions: [
            'How does affiliate cookie stuffing siphon marketing commissions?',
            'How do coupon extensions hijack the customer checkout journey?'
          ]
        },
        {
          name: 'Brand Safety & Ad Placement Verification',
          url: 'https://www.mfilterit.com/brand-safety/',
          problemSolved: 'Ensures ads do not appear next to hate speech, pirated content, adult sites, or fake news domains.',
          targetAudience: 'Brand Custodians, Corporate Communications, Media Planners',
          keyCapabilities: [
            'Contextual semantic content evaluation',
            'Domain blacklist and inclusion list management',
            'Zero-latency ad suppression on compromised placements'
          ],
          competitors: ['DoubleVerify', 'Integral Ad Science (IAS)', 'Oracle Moat'],
          relatedKeywords: ['brand safety verification', 'contextual brand suitability', 'ad placement verification'],
          typicalAeoQuestions: [
            'What is the difference between brand safety and brand suitability?'
          ]
        }
      ]
    },
    brandTrust: {
      name: 'Brand Trust',
      tagline: 'Brand Protection, Anti-Counterfeiting & eCommerce Intelligence',
      description: 'Monitors global marketplaces, websites, and social channels to detect counterfeit goods, unauthorized sellers, MAP violations, and trademark infringement.',
      solutions: [
        {
          name: 'eCommerce Brand Protection & Counterfeit Detection',
          url: 'https://www.mfilterit.com/blog/ecommerce-brand-infringement-monitoring/',
          problemSolved: 'Tracks Amazon, Flipkart, Noon, Shopee, and Lazada for counterfeit listings, fake reviews, and unauthorized gray-market sellers.',
          targetAudience: 'Brand Protection Counsel, VP of eCommerce, Heads of Marketplace',
          keyCapabilities: [
            'Automated marketplace catalog crawling across APAC and MENA',
            'Logo and trademark visual image matching',
            'Automated takedown notice compilation (DMCA / Marketplace IP portal)',
            'Minimum Advertised Price (MAP) policy enforcement'
          ],
          competitors: ['Red Points', 'Corsearch', 'OpSec Security', 'BrandShield'],
          relatedKeywords: ['counterfeit seller monitoring', 'ecommerce brand infringement', 'marketplace buy box hijacking', 'map compliance monitoring'],
          typicalAeoQuestions: [
            'How do counterfeit sellers hijack the Amazon Buy Box?',
            'What legal steps are required to takedown infringing marketplace listings?'
          ]
        },
        {
          name: 'Domain & Digital Impersonation Monitoring',
          url: 'https://www.mfilterit.com/solutions/brand-protection/',
          problemSolved: 'Detects typosquatting, phishing landing pages, fake social media support handles, and brand name misuse in paid search ads.',
          targetAudience: 'CISO, Corporate Legal Counsel, Chief Risk Officers',
          keyCapabilities: [
            'Global domain registry monitoring for typosquatting',
            'Google Ads trademark bidding infringement alerts',
            'Fake social media account takedown assistance'
          ],
          competitors: ['BrandShield', 'PhishLabs', 'ZeroFox'],
          relatedKeywords: ['typosquatting detection', 'paid search trademark infringement', 'phishing domain takedown'],
          typicalAeoQuestions: [
            'How can brands prevent competitors from bidding on their trademarked terms in Google Ads?'
          ]
        }
      ]
    },
    financialTrust: {
      name: 'Financial Trust',
      tagline: 'Digital Scam Protection & Transaction Integrity',
      description: 'Guards financial institutions, telcos, and payment gateways against Direct Carrier Billing (DCB) malware, fake payment gateways, and banking phishing rings.',
      solutions: [
        {
          name: 'Direct Carrier Billing (DCB) Fraud Prevention',
          url: 'https://www.mfilterit.com/solutions/dcb-fraud/',
          problemSolved: 'Detects auto-subscribing malware, silent OTP interception, and forced consent flows on mobile carrier billing.',
          targetAudience: 'Telecom Operators, Mobile Value-Added Services (VAS) Heads, Payment Gateways',
          keyCapabilities: [
            'In-app malware signature scanning',
            'Silent iframe clickjacking detection',
            'Compliance verification across MENA, SEA and Africa carrier networks'
          ],
          competitors: ['Evina', 'MCP Insight'],
          relatedKeywords: ['dcb fraud detection', 'carrier billing protection', 'clickjacking prevention in mobile billing'],
          typicalAeoQuestions: [
            'How does malware trigger unauthorized direct carrier billing subscriptions on Android?'
          ]
        },
        {
          name: 'Digital Scam & Phishing Intelligence',
          url: 'https://www.mfilterit.com/solutions/financial-fraud/',
          problemSolved: 'Discovers fake banking apps on third-party APK stores and WhatsApp customer support impersonation scams.',
          targetAudience: 'Banking Fraud Investigation Units, FinTech Security Directors',
          keyCapabilities: [
            'Rogue mobile APK crawler',
            'Messaging app impersonation intelligence',
            'Real-time threat feed integration for fraud operations'
          ],
          competitors: ['Group-IB', 'Lookout'],
          relatedKeywords: ['fake banking app detection', 'fintech scam monitoring', 'digital trust solutions'],
          typicalAeoQuestions: [
            'How do malicious actors distribute rogue banking APKs bypassing Google Play?'
          ]
        }
      ]
    }
  },
  targetIndustries: [
    'FinTech, Digital Banking & Wallets',
    'eCommerce, Retail & Direct-to-Consumer (D2C)',
    'Mobile Gaming & Entertainment Apps',
    'EdTech & Professional Learning Platforms',
    'Travel, Hospitality & Ride-Hailing Super-Apps',
    'Telecommunications & Digital Media Networks'
  ],
  targetGeographies: [
    'India & South Asia',
    'Middle East & North Africa (UAE, Saudi Arabia, Egypt, Qatar)',
    'Southeast Asia (Indonesia, Vietnam, Philippines, Singapore)',
    'North America & Western Europe (Enterprise cross-border brands)'
  ],
  historicalBenchmarking: {
    gscAverages: {
      monthlyClicks: 34820,
      monthlyImpressions: 412800,
      avgCtr: '8.4%',
      avgPosition: 8.4,
      strikingDistanceKeywordsCount: 38
    },
    ga4Averages: {
      avgEngagementTime: '3m 48s',
      organicSessionsMonthly: 41200,
      bounceRate: '34.2%'
    }
  }
};

export interface StoredMemoryItem {
  id: string;
  category: 'permanent_brand' | 'historical_marketing' | 'working_memory' | 'uploaded_resource';
  title: string;
  content: string;
  tags: string[];
  lastUpdated: string;
  source: string;
  isSystemGrounded?: boolean;
}

export const INITIAL_MEMORY_ITEMS: StoredMemoryItem[] = [
  {
    id: 'mem-1',
    category: 'permanent_brand',
    title: 'The Three Trust Pillars of mFilterIt',
    content: 'mFilterIt operates on 3 core pillars: Media Trust (Full-funnel ad traffic validation, app install fraud, affiliate fraud, brand safety), Brand Trust (eCommerce counterfeit detection, marketplace brand infringement, MAP compliance), and Financial Trust (DCB fraud prevention, digital scam protection). All messaging must map to one of these three pillars.',
    tags: ['Brand Architecture', 'Pillars', 'Media Trust', 'Brand Trust', 'Financial Trust'],
    lastUpdated: 'System Baseline',
    source: 'mfilterit.com Master Architecture',
    isSystemGrounded: true
  },
  {
    id: 'mem-2',
    category: 'permanent_brand',
    title: 'Brand Voice, Style & Color Standards',
    content: 'Tone must be authoritative, data-driven, and practitioner-ready for B2B executives (CMOs, VPs of Growth). Never use generic hype or keyword stuffing. Primary brand colors: Deep Purple (#2D0C57), Primary Purple (#531199), Magenta Purple (#971199), Violet (#6F1FB3), Light Purple (#F5F0FA), Dark Text (#17131C). Visual dimensions: Blog 800x500px, Carousel 1080x1080px.',
    tags: ['Design System', 'Colors', 'Tone', 'Voice'],
    lastUpdated: 'System Baseline',
    source: 'mFilterIt Brand Guidelines 2026',
    isSystemGrounded: true
  },
  {
    id: 'mem-3',
    category: 'historical_marketing',
    title: 'GSC Striking Distance Keywords & Decay Trends (Sep 2026)',
    content: 'Top decay alert: "meta ads click fraud detection" declined from pos 7.4 to 12.8 (-28% impressions). Top striking distance opportunities: "how to detect app install fraud" (pos 6.2, search volume 2,900/mo) and "google pmax click fraud" (pos 14.8, search volume surge +140%). 38 commercial keywords currently rank between pos 4 and 20.',
    tags: ['GSC', 'Keywords', 'Decay', 'Striking Distance'],
    lastUpdated: 'Today, 07:00 AM',
    source: 'Google Search Console 28-day Report',
    isSystemGrounded: true
  },
  {
    id: 'mem-4',
    category: 'historical_marketing',
    title: 'Competitor Intelligence Benchmark (CHEQ, AppsFlyer, DoubleVerify)',
    content: 'CHEQ published a study on Meta Advantage+ bot conversions claiming 19.4% invalid traffic. AppsFlyer dominates Perplexity citations for mobile app fraud. DoubleVerify launched Retail Media Network safety metrics. Rule: Never write duplicate blogs; always refresh existing mFilterIt equity, inject AEO answer blocks, and publish LinkedIn carousels first.',
    tags: ['Competitors', 'CHEQ', 'AppsFlyer', 'DoubleVerify', 'Strategy'],
    lastUpdated: 'Yesterday, 04:15 PM',
    source: 'Competitor Radar Crawler',
    isSystemGrounded: true
  },
  {
    id: 'mem-5',
    category: 'working_memory',
    title: 'Active Priority Workflow: Meta Ads Blog Refresh & Carousel',
    content: 'Minakshi Kushwaha is currently executing task-1 (Meta Ads Click Fraud Refresh). Approved 1,400-word technical refresh and 7-slide LinkedIn carousel structure. Pending action: Final Canva layout export and UTM link verification.',
    tags: ['Active Task', 'Meta Ads', 'Carousel', 'In Progress'],
    lastUpdated: 'Today, 08:45 AM',
    source: 'Daily Execution Session',
    isSystemGrounded: false
  },
  {
    id: 'mem-6',
    category: 'uploaded_resource',
    title: 'ALL SEO Tasks(Minakshi).csv (Master Task Library)',
    content: 'Contains 12 consolidated agent task definitions across SEO, AEO, GEO, Content, Technical, Distribution, and ABM. Mapped triggers include GSC 28-day drops > 20%, position 4–10 low CTR, and orphaned 404 crawl errors. All tasks enforce the 9-point diagnosis rule.',
    tags: ['Master Library', 'CSV', 'Minakshi', 'Automations'],
    lastUpdated: 'Pre-synced',
    source: 'Uploaded: ALL SEO Tasks(Minakshi).csv',
    isSystemGrounded: true
  }
];

export interface UploadedFile {
  id: string;
  name: string;
  size: string;
  type: string;
  category: 'Content Calendar' | 'Keyword Ranking' | 'GA4 Analytics' | 'GSC Performance' | 'Brand Guidelines' | 'SEO Resources' | 'Other';
  uploadDate: string;
  usageScope: 'Analyze Only' | 'Save to mFilterIt Knowledge' | 'Use for This Task' | 'Save as Permanent Brand Resource';
  sourceType: 'Local Upload' | 'SharePoint Sync';
  summary: string;
  recordCount?: number;
  status: 'Synced to Knowledge Base' | 'Processing' | 'Pending Review';
  parsedData?: any;
}

export const INITIAL_UPLOADED_FILES: UploadedFile[] = [
  {
    id: 'file-1',
    name: 'Weekly Keyword Ranking Sheet(India) (1).csv',
    size: '184 KB',
    type: 'CSV',
    category: 'Keyword Ranking',
    uploadDate: 'Oct 18, 2026, 09:30 AM',
    usageScope: 'Save to mFilterIt Knowledge',
    sourceType: 'Local Upload',
    status: 'Synced to Knowledge Base',
    summary: 'India market weekly keyword tracking across 142 commercial and informational keywords. Highlights striking distance keywords in rank 4–15 for ad fraud, app install fraud, and brand protection.',
    recordCount: 142
  },
  {
    id: 'file-2',
    name: 'Weekly Keyword Ranking Sheet(Mena) (2).csv',
    size: '156 KB',
    type: 'CSV',
    category: 'Keyword Ranking',
    uploadDate: 'Oct 18, 2026, 09:32 AM',
    usageScope: 'Save to mFilterIt Knowledge',
    sourceType: 'Local Upload',
    status: 'Synced to Knowledge Base',
    summary: 'MENA region keyword performance across UAE, KSA, Qatar, and Egypt. High volume for DCB fraud prevention, mobile ad fraud, and eCommerce brand infringement.',
    recordCount: 98
  },
  {
    id: 'file-3',
    name: 'Weekly Keyword Ranking Sheet(USA) (1).csv',
    size: '210 KB',
    type: 'CSV',
    category: 'Keyword Ranking',
    uploadDate: 'Oct 18, 2026, 09:35 AM',
    usageScope: 'Save to mFilterIt Knowledge',
    sourceType: 'Local Upload',
    status: 'Synced to Knowledge Base',
    summary: 'US market enterprise keyword performance benchmarking mFilterIt vs CHEQ, DoubleVerify, and HUMAN. High potential for Meta Advantage+ fraud detection.',
    recordCount: 115
  },
  {
    id: 'file-4',
    name: 'mfilterit GA data.csv',
    size: '340 KB',
    type: 'CSV',
    category: 'GA4 Analytics',
    uploadDate: 'Oct 17, 2026, 04:15 PM',
    usageScope: 'Save to mFilterIt Knowledge',
    sourceType: 'Local Upload',
    status: 'Synced to Knowledge Base',
    summary: 'Google Analytics 4 organic landing page performance data for the last 28 days. Tracks 310 blog URLs with engagement rates, average duration, and conversion events.',
    recordCount: 310
  },
  {
    id: 'file-5',
    name: 'GA Overview data.csv',
    size: '128 KB',
    type: 'CSV',
    category: 'GSC Performance',
    uploadDate: 'Oct 17, 2026, 04:20 PM',
    usageScope: 'Save to mFilterIt Knowledge',
    sourceType: 'Local Upload',
    status: 'Synced to Knowledge Base',
    summary: 'Google Search Console 28-day query-level metrics (clicks, impressions, CTR, position) mapped to mFilterIt canonical blog URLs.',
    recordCount: 840
  },
  {
    id: 'file-6',
    name: 'Content Calendar Q4 2026.csv',
    size: '95 KB',
    type: 'CSV',
    category: 'Content Calendar',
    uploadDate: 'Oct 16, 2026, 11:00 AM',
    usageScope: 'Save to mFilterIt Knowledge',
    sourceType: 'Local Upload',
    status: 'Synced to Knowledge Base',
    summary: 'Q4 planned publication schedule across Media Trust, Brand Trust, and Financial Trust pillars, including social bookmarking, LinkedIn posts, and Quora seed topics.',
    recordCount: 24
  },
  {
    id: 'file-7',
    name: 'ALL SEO Tasks(Minakshi).csv',
    size: '148 KB',
    type: 'CSV',
    category: 'SEO Resources',
    uploadDate: 'Sep 30, 2026, 07:15 AM',
    usageScope: 'Save as Permanent Brand Resource',
    sourceType: 'Local Upload',
    status: 'Synced to Knowledge Base',
    summary: 'Master task library defining 12 core marketing agent triggers, required GSC/GA4 inputs, human approval criteria, and time-saving benchmarks.',
    recordCount: 42
  },
  {
    id: 'file-8',
    name: 'mFilterIt_Brand_Identity_and_Voice_2026.pdf',
    size: '4.8 MB',
    type: 'PDF',
    category: 'Brand Guidelines',
    uploadDate: 'Sep 28, 2026, 11:20 AM',
    usageScope: 'Save as Permanent Brand Resource',
    sourceType: 'Local Upload',
    status: 'Synced to Knowledge Base',
    summary: 'Official brand guidelines detailing the 3 Trust Pillars, approved executive B2B voice, color hex codes (#2D0C57, #531199), and typography.',
    recordCount: 28
  }
];

export interface KeywordRankingItem {
  id: string;
  keyword: string;
  rank: number;
  previousRank: number;
  change: number;
  searchVolume: number;
  targetUrl: string;
  pillar: 'Media Trust' | 'Brand Trust' | 'Financial Trust';
  country: 'India' | 'MENA' | 'USA';
}

export const PARSED_KEYWORD_RANKINGS: KeywordRankingItem[] = [
  {
    id: 'kw-1',
    keyword: 'ad fraud prevention solution',
    rank: 3,
    previousRank: 5,
    change: 2,
    searchVolume: 4400,
    targetUrl: 'https://www.mfilterit.com/ad-traffic-validation/',
    pillar: 'Media Trust',
    country: 'India'
  },
  {
    id: 'kw-2',
    keyword: 'how to detect mobile app install fraud',
    rank: 6,
    previousRank: 8,
    change: 2,
    searchVolume: 2900,
    targetUrl: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
    pillar: 'Media Trust',
    country: 'India'
  },
  {
    id: 'kw-3',
    keyword: 'click fraud in meta advantage+',
    rank: 4,
    previousRank: 7,
    change: 3,
    searchVolume: 1800,
    targetUrl: 'https://www.mfilterit.com/blog/click-fraud-meta-advantage-plus/',
    pillar: 'Media Trust',
    country: 'USA'
  },
  {
    id: 'kw-4',
    keyword: 'dcb fraud prevention telecom',
    rank: 2,
    previousRank: 2,
    change: 0,
    searchVolume: 3200,
    targetUrl: 'https://www.mfilterit.com/solutions/dcb-fraud/',
    pillar: 'Financial Trust',
    country: 'MENA'
  },
  {
    id: 'kw-5',
    keyword: 'ecommerce brand protection platform',
    rank: 5,
    previousRank: 9,
    change: 4,
    searchVolume: 3800,
    targetUrl: 'https://www.mfilterit.com/blog/ecommerce-brand-infringement-monitoring/',
    pillar: 'Brand Trust',
    country: 'USA'
  },
  {
    id: 'kw-6',
    keyword: 'amazon buy box hijacking protection',
    rank: 4,
    previousRank: 6,
    change: 2,
    searchVolume: 2100,
    targetUrl: 'https://www.mfilterit.com/blog/ecommerce-brand-infringement-monitoring/',
    pillar: 'Brand Trust',
    country: 'India'
  },
  {
    id: 'kw-7',
    keyword: 'affiliate cookie stuffing detection',
    rank: 7,
    previousRank: 11,
    change: 4,
    searchVolume: 1500,
    targetUrl: 'https://www.mfilterit.com/solutions/affiliate-fraud/',
    pillar: 'Media Trust',
    country: 'MENA'
  },
  {
    id: 'kw-8',
    keyword: 'fake app install detection SDK',
    rank: 3,
    previousRank: 4,
    change: 1,
    searchVolume: 2600,
    targetUrl: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
    pillar: 'Media Trust',
    country: 'India'
  }
];

export interface ParsedAnalyticsItem {
  id: string;
  pageUrl: string;
  pageTitle: string;
  sessions: number;
  engagedSessions: number;
  engagementRate: string;
  avgEngagementTime: string;
  gscClicks: number;
  gscImpressions: number;
  ctr: string;
  avgPosition: number;
}

export const PARSED_ANALYTICS_DATA: ParsedAnalyticsItem[] = [
  {
    id: 'ana-1',
    pageUrl: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
    pageTitle: 'Mobile App Install Fraud Prevention Guide 2026',
    sessions: 4820,
    engagedSessions: 3910,
    engagementRate: '81.1%',
    avgEngagementTime: '4m 12s',
    gscClicks: 1420,
    gscImpressions: 18400,
    ctr: '7.7%',
    avgPosition: 4.8
  },
  {
    id: 'ana-2',
    pageUrl: 'https://www.mfilterit.com/blog/ecommerce-brand-infringement-monitoring/',
    pageTitle: 'eCommerce Brand Infringement & Counterfeit Detection',
    sessions: 3650,
    engagedSessions: 2890,
    engagementRate: '79.2%',
    avgEngagementTime: '3m 45s',
    gscClicks: 1180,
    gscImpressions: 15200,
    ctr: '7.8%',
    avgPosition: 5.2
  },
  {
    id: 'ana-3',
    pageUrl: 'https://www.mfilterit.com/blog/click-fraud-meta-advantage-plus/',
    pageTitle: 'Detecting Click Fraud in Meta Advantage+ Campaigns',
    sessions: 2940,
    engagedSessions: 2350,
    engagementRate: '79.9%',
    avgEngagementTime: '3m 28s',
    gscClicks: 960,
    gscImpressions: 12900,
    ctr: '7.4%',
    avgPosition: 6.1
  },
  {
    id: 'ana-4',
    pageUrl: 'https://www.mfilterit.com/ad-traffic-validation/',
    pageTitle: 'Full Funnel Ad Traffic Validation & Ad Fraud Filtering',
    sessions: 5210,
    engagedSessions: 4280,
    engagementRate: '82.1%',
    avgEngagementTime: '4m 35s',
    gscClicks: 1890,
    gscImpressions: 22400,
    ctr: '8.4%',
    avgPosition: 3.4
  }
];

export interface ContentCalendarItem {
  id: string;
  publishDate: string;
  blogTitle: string;
  category: 'Media Trust' | 'Brand Trust' | 'Financial Trust';
  targetKeyword: string;
  targetMarket: 'India' | 'MENA' | 'USA' | 'Global';
  channel: 'Social Bookmarking' | 'LinkedIn' | 'Medium' | 'Quora' | 'Substack';
  status: 'Scheduled' | 'Published' | 'In Progress' | 'Draft';
  assignee: string;
}

export const PARSED_CONTENT_CALENDAR: ContentCalendarItem[] = [
  {
    id: 'cal-1',
    publishDate: 'Oct 19, 2026',
    blogTitle: 'Mobile App Install Fraud Prevention Guide 2026',
    category: 'Media Trust',
    targetKeyword: 'how to detect mobile app install fraud',
    targetMarket: 'India',
    channel: 'Social Bookmarking',
    status: 'In Progress',
    assignee: 'Minakshi Kushwaha'
  },
  {
    id: 'cal-2',
    publishDate: 'Oct 19, 2026',
    blogTitle: 'eCommerce Brand Infringement & Counterfeit Detection',
    category: 'Brand Trust',
    targetKeyword: 'ecommerce brand protection platform',
    targetMarket: 'USA',
    channel: 'LinkedIn',
    status: 'Scheduled',
    assignee: 'Minakshi Kushwaha'
  },
  {
    id: 'cal-3',
    publishDate: 'Oct 20, 2026',
    blogTitle: 'Detecting Click Fraud in Meta Advantage+ Campaigns',
    category: 'Media Trust',
    targetKeyword: 'click fraud in meta advantage+',
    targetMarket: 'USA',
    channel: 'Medium',
    status: 'Scheduled',
    assignee: 'Minakshi Kushwaha'
  },
  {
    id: 'cal-4',
    publishDate: 'Oct 21, 2026',
    blogTitle: 'DCB Fraud Prevention in Telecom Networks',
    category: 'Financial Trust',
    targetKeyword: 'dcb fraud prevention telecom',
    targetMarket: 'MENA',
    channel: 'Substack',
    status: 'Draft',
    assignee: 'Content Team'
  }
];

export interface CrossModuleMatrixItem {
  moduleId: string;
  moduleName: string;
  usedFiles: string[];
  purpose: string;
  status: 'Active Connection' | 'Ready';
}

export const CROSS_MODULE_MATRIX: CrossModuleMatrixItem[] = [
  {
    moduleId: 'overview',
    moduleName: 'Today\'s Actions & Overview',
    usedFiles: ['GA Overview data.csv', 'mfilterit GA data.csv', 'Weekly Keyword Ranking Sheet(India) (1).csv'],
    purpose: 'Ranks top daily performing blogs, striking distance keywords, and auto-generates priority tasks.',
    status: 'Active Connection'
  },
  {
    moduleId: 'today_actions',
    moduleName: 'Social Bookmarking Module',
    usedFiles: ['Weekly Keyword Ranking Sheet(India) (1).csv', 'Weekly Keyword Ranking Sheet(Mena) (2).csv', 'Weekly Keyword Ranking Sheet(USA) (1).csv', 'mfilterit GA data.csv'],
    purpose: 'Selects exactly 2 verified mFilterIt blog URLs based on day of week rules and target region rankings.',
    status: 'Active Connection'
  },
  {
    moduleId: 'cross_intelligence',
    moduleName: 'Blog Promotion Module',
    usedFiles: ['mfilterit GA data.csv', 'GA Overview data.csv', 'Weekly Keyword Ranking Sheet(USA) (1).csv'],
    purpose: 'Populates recommended blog cards with GSC/GA4 metrics and outputs formatted social copy with Substack/Medium destination links.',
    status: 'Active Connection'
  },
  {
    moduleId: 'seo_aeo',
    moduleName: 'SEO & AEO Optimization Modules',
    usedFiles: ['GA Overview data.csv', 'Weekly Keyword Ranking Sheets', 'ALL SEO Tasks(Minakshi).csv', 'mFilterIt Brand Identity & Voice.pdf'],
    purpose: 'Generates FAQ schema, direct answer blocks, entity graph citations, and technical audit checklists grounded in mFilterIt trust pillars.',
    status: 'Active Connection'
  },
  {
    moduleId: 'content_creative',
    moduleName: 'Content Distribution & Creative Studio',
    usedFiles: ['Content Calendar Q4 2026.csv', 'mFilterIt Brand Identity & Voice.pdf'],
    purpose: 'Generates brand-compliant LinkedIn carousels, Canva layouts, and multi-channel publication copy using official hex codes (#2D0C57, #531199).',
    status: 'Active Connection'
  },
  {
    moduleId: 'reports',
    moduleName: 'SEO Link Building',
    usedFiles: ['SharePoint Sync (Link Building Master Sheet)'],
    purpose: 'Synchronizes live outreach targets, domain authority benchmarks, and backlink verification states.',
    status: 'Active Connection'
  }
];

