export interface MasterTaskDefinition {
  id: string;
  taskName: string;
  category: 'SEO' | 'AEO' | 'GEO' | 'Content' | 'Distribution' | 'Technical' | 'ABM';
  subcategory: string;
  agentGroup: string;
  trigger: string;
  requiredData: string[];
  aiAction: string;
  humanApprovalRequired: boolean;
  outputType: string;
  channel: string;
  estimatedManualMinutes: number;
  estimatedAiMinutes: number;
}

export const MASTER_TASK_LIBRARY: MasterTaskDefinition[] = [
  {
    id: 'LIB-SEO-01',
    taskName: 'Content Decay & Drop Refresh Analysis',
    category: 'SEO',
    subcategory: 'Content SEO',
    agentGroup: 'SEO Execution Agent',
    trigger: 'GSC 28-day impression drop > 20% or position drop > 3 positions',
    requiredData: ['GSC Clicks & Impressions', 'GA4 Engagement Time', 'Competitor Content Diff'],
    aiAction: 'Analyzes keyword intent loss, identifies outdated sections, extracts competitor coverage, generates refresh draft + internal link recommendations.',
    humanApprovalRequired: true,
    outputType: 'Optimized blog draft + heading structure + metadata',
    channel: 'Website Blog',
    estimatedManualMinutes: 120,
    estimatedAiMinutes: 15
  },
  {
    id: 'LIB-SEO-02',
    taskName: 'Striking Distance Keyword Optimization (Pos 4-10, 11-20)',
    category: 'SEO',
    subcategory: 'Keyword Intelligence',
    agentGroup: 'Keyword Intelligence Agent',
    trigger: 'High search volume keywords ranking between position 4 and 20 with low CTR',
    requiredData: ['GSC Query Position Report', 'Current Page H1/H2s', 'Top 3 SERP Competitor Headings'],
    aiAction: 'Detects secondary semantic keywords, re-optimizes title/meta, suggests semantic subheadings and contextual body insertions.',
    humanApprovalRequired: true,
    outputType: 'On-page keyword insertion plan + metadata suggestions',
    channel: 'Website Page',
    estimatedManualMinutes: 60,
    estimatedAiMinutes: 8
  },
  {
    id: 'LIB-SEO-03',
    taskName: 'Internal Linking Gap Analysis & Topical Siloing',
    category: 'SEO',
    subcategory: 'On-Page SEO',
    agentGroup: 'Internal Linking Agent',
    trigger: 'New blog publication or orphaned high-authority commercial page',
    requiredData: ['Website Sitemap / All URLs', 'Target Keywords', 'Existing Anchor Distribution'],
    aiAction: 'Scans existing content base, maps contextual anchor opportunities with exact sentence location and semantic reason.',
    humanApprovalRequired: true,
    outputType: 'Anchor table (Source URL, Target URL, Anchor text, Paragraph, Reason)',
    channel: 'Website Blog / Solutions',
    estimatedManualMinutes: 45,
    estimatedAiMinutes: 4
  },
  {
    id: 'LIB-AEO-01',
    taskName: 'Direct Answer Block & Featured Snippet Capture',
    category: 'AEO',
    subcategory: 'Answer Optimization',
    agentGroup: 'AEO Optimization Agent',
    trigger: 'Query captures PAA or Featured Snippet held by competitor with high volume',
    requiredData: ['Google SERP PAA questions', 'Current page paragraph length', 'Competitor snippet format'],
    aiAction: 'Drafts concise 40-55 word direct-answer definitions, bulleted answer lists, and comparison tables structured for zero-click queries.',
    humanApprovalRequired: true,
    outputType: 'Direct Answer Blocks + PAA response module',
    channel: 'Website Content',
    estimatedManualMinutes: 50,
    estimatedAiMinutes: 5
  },
  {
    id: 'LIB-AEO-02',
    taskName: 'FAQ Expansion & Schema.org JSON-LD Generation',
    category: 'AEO',
    subcategory: 'Technical AEO',
    agentGroup: 'AEO Optimization Agent',
    trigger: 'Page lacks FAQ schema or ranks on page 1 without accordion rich result',
    requiredData: ['People Also Ask queries', 'Customer sales questions', 'Search Console question queries'],
    aiAction: 'Generates 4-6 high-intent question-answer pairs + creates validated JSON-LD FAQPage markup ready for insertion.',
    humanApprovalRequired: true,
    outputType: 'FAQ text + Copyable JSON-LD code block',
    channel: 'Website CMS / Schema',
    estimatedManualMinutes: 45,
    estimatedAiMinutes: 5
  },
  {
    id: 'LIB-GEO-01',
    taskName: 'Generative Engine Brand Entity & Citation Optimization',
    category: 'GEO',
    subcategory: 'AI Search Visibility',
    agentGroup: 'GEO Optimization Agent',
    trigger: 'mFilterIt brand or solution missing from Perplexity, ChatGPT, or Gemini queries',
    requiredData: ['Perplexity citation audit', 'Competitor AI answers', 'mFilterIt product specs'],
    aiAction: 'Creates quotation-ready statistical benchmarks, structured entity triples, and clear comparative tables optimized for LLM RAG ingestion.',
    humanApprovalRequired: true,
    outputType: 'Authoritative data callout block + Product schema with sameAs',
    channel: 'Website / AI Knowledge Bases',
    estimatedManualMinutes: 90,
    estimatedAiMinutes: 12
  },
  {
    id: 'LIB-CONT-01',
    taskName: 'Competitor Reactive Content Assessment & Strategy',
    category: 'Content',
    subcategory: 'Competitor Intelligence',
    agentGroup: 'Competitor Intelligence Agent',
    trigger: 'Competitor (CHEQ, AppsFlyer, DoubleVerify) publishes new article or updates report',
    requiredData: ['Competitor URL / Content', 'mFilterIt existing catalog', 'Keyword difficulty'],
    aiAction: 'Determines whether mFilterIt should Refresh existing, Add section, Add FAQ, Build links, or Create new article. Prevents duplicate content.',
    humanApprovalRequired: true,
    outputType: 'Competitor Impact Triage + Exact Execution Plan',
    channel: 'Content Strategy',
    estimatedManualMinutes: 60,
    estimatedAiMinutes: 8
  },
  {
    id: 'LIB-DIST-01',
    taskName: 'B2B LinkedIn Carousel Asset Generation & Canva Bridge',
    category: 'Distribution',
    subcategory: 'Visual Repurposing',
    agentGroup: 'Creative & Distribution Agent',
    trigger: 'High-performing blog asset requiring executive social amplification',
    requiredData: ['Blog content', 'Audience persona', 'Visual format templates'],
    aiAction: 'Structures 7-slide B2B carousel (Hook, Problem, Why, Signals, Impact, Action, CTA) with visual design prompts for Canva.',
    humanApprovalRequired: true,
    outputType: 'Slide-by-slide copy + Visual layout directives + UTM links',
    channel: 'LinkedIn Document / Carousel',
    estimatedManualMinutes: 90,
    estimatedAiMinutes: 10
  },
  {
    id: 'LIB-DIST-02',
    taskName: 'Quora High-Intent Answer & Solution Citation',
    category: 'Distribution',
    subcategory: 'Community Q&A',
    agentGroup: 'Quora Agent',
    trigger: 'Quora question ranking on page 1 of Google with > 1k views',
    requiredData: ['Quora thread URL', 'Related mFilterIt blog', 'Technical data points'],
    aiAction: 'Drafts comprehensive, highly valuable technical answer with natural context link and tracked UTM parameters.',
    humanApprovalRequired: true,
    outputType: 'Formatted Quora answer + Tracked source link',
    channel: 'Quora',
    estimatedManualMinutes: 45,
    estimatedAiMinutes: 5
  },
  {
    id: 'LIB-DIST-03',
    taskName: 'Controlled Reddit Community Contribution Triage',
    category: 'Distribution',
    subcategory: 'Community Q&A',
    agentGroup: 'Reddit Agent',
    trigger: 'Subreddit discussion on ad fraud, invalid traffic, or ad spend waste',
    requiredData: ['Reddit post text', 'Subreddit rules', 'Promotional risk score'],
    aiAction: 'Assesses subreddit rules and promotional risk. Outputs strict ANSWER or DO NOT ANSWER recommendation with non-promotional educational copy.',
    humanApprovalRequired: true,
    outputType: 'Reddit risk score + Non-promotional answer text (or rejection advice)',
    channel: 'Reddit (r/marketing, r/PPC, r/adops)',
    estimatedManualMinutes: 40,
    estimatedAiMinutes: 4
  },
  {
    id: 'LIB-TECH-01',
    taskName: '404 Redirection Mapping & Crawl Error Recovery',
    category: 'Technical',
    subcategory: 'Technical SEO',
    agentGroup: 'Technical SEO Agent',
    trigger: '404 errors detected with referring domains or GSC crawl impressions',
    requiredData: ['Crawl error log', 'Referring domain metrics', 'Live URL sitemap'],
    aiAction: 'Maps broken legacy URLs to closest thematic live canonical destination with 301 rules.',
    humanApprovalRequired: true,
    outputType: '301 redirect configuration rules (.htaccess / NGINX / Cloudflare)',
    channel: 'Server / CDN',
    estimatedManualMinutes: 40,
    estimatedAiMinutes: 3
  },
  {
    id: 'LIB-ABM-01',
    taskName: 'Enterprise Account Ad Fraud Vulnerability Brief',
    category: 'ABM',
    subcategory: 'Account Intelligence',
    agentGroup: 'ABM Intelligence Agent',
    trigger: 'High ad-spend enterprise account in target geography entering seasonal peak',
    requiredData: ['Target Account ad channels', 'Public campaign assets', 'Industry fraud benchmarks'],
    aiAction: 'Researches key decision maker personas, identifies suspected fraud vectors, and creates an executive brief (Zero automated email).',
    humanApprovalRequired: true,
    outputType: 'Executive One-Pager & Strategic Meeting Brief',
    channel: 'Sales Enablement / LinkedIn InMail',
    estimatedManualMinutes: 120,
    estimatedAiMinutes: 15
  }
];
