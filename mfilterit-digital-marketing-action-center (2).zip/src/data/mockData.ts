import { 
  TaskRecommendation, 
  CompetitorEvent, 
  AeoOpportunity, 
  GeoOpportunity, 
  AuditLogEntry, 
  AbmAccount, 
  TechnicalSeoIssue,
  InternalLinkOpportunity,
  CarouselSlide,
  UtmLinkItem
} from '../types';

export const INITIAL_TASKS: TaskRecommendation[] = [
  {
    id: 'task-1',
    taskName: 'Meta Ads Fraud Detection & Invalid Clicks Refresh',
    category: 'SEO',
    subcategory: 'Content Refresh & AEO/GEO Integration',
    priority: 'high',
    status: 'ai_recommended',
    url: 'https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/',
    targetKeyword: 'meta ads click fraud detection',
    channel: 'Website Blog + LinkedIn + Quora',
    signal: 'GSC impressions decreased 28% over 28 days (from 42,300 to 30,450).',
    evidence: 'Organic clicks dropped 19% and average position fell from 7.4 to 12.8 for high-intent keywords. 2 competitors (CHEQ & AppsFlyer) recently published fresh guides on Meta Advantage+ fraud.',
    diagnosis: 'Existing content is losing topical authority and search visibility because it lacks 2026 Advantage+ bot patterns, conversational answer blocks, and AI search entity citations.',
    reason: 'The page already has 18 months of domain search equity and existing backlinks; refreshing the existing asset with new fraud vectors, AEO answers, and internal links produces 3x faster ranking recovery than creating a new URL.',
    recommendedAction: 'Refresh content with Meta Advantage+ fraud vectors + add 5 AEO answer blocks + enrich GEO brand entities + inject 4 contextual internal links + create LinkedIn carousel distribution.',
    expectedOutcome: 'Recover position 4–6 on GSC, capture 6 People Also Ask snippets, and regain ~4,800 monthly organic impressions within 21 days.',
    approvalRequired: true,
    prioritizationScore: 94,
    scoreFactors: {
      businessImpact: 9.6,
      searchOpportunity: 9.3,
      competitorPressure: 9.5,
      contentGap: 9.1,
      urgency: 9.4
    },
    timeSavedMinutes: 135,
    createdDate: 'Today, 07:45 AM'
  },
  {
    id: 'task-2',
    taskName: 'Mobile App Install Fraud Prevention for Fintech & Gaming',
    category: 'AEO',
    subcategory: 'Direct Answer Optimization & FAQ Schema',
    priority: 'high',
    status: 'awaiting_approval',
    url: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
    targetKeyword: 'how to detect app install fraud',
    channel: 'Website FAQ + LinkedIn Document + Infographic',
    signal: 'GSC displays 8,400 monthly impressions for question queries ("how does install fraud happen", "device spoofing vs SDK spoofing") with zero featured snippets captured.',
    evidence: 'Average position is 6.2, but CTR is only 1.8% because competitor Adjust holds the featured snippet with a structured definition answer.',
    diagnosis: 'Content is comprehensive (2,400 words) but fails AEO answer-first formatting; it lacks concise 45-word direct answer blocks and structured FAQPage schema.',
    reason: 'Google and AI search engines prioritize modular, direct answer definitions over long prose for conversational queries.',
    recommendedAction: 'Inject 3 structured Definition & Comparison answer blocks at the top of H2s + deploy JSON-LD FAQ schema + publish visual install fraud flow infographic.',
    expectedOutcome: 'Win Featured Snippet & PAA placement, lifting CTR from 1.8% to 5.4% (~850 additional qualified visits/month).',
    approvalRequired: true,
    prioritizationScore: 89,
    scoreFactors: {
      businessImpact: 8.8,
      searchOpportunity: 9.2,
      competitorPressure: 8.7,
      contentGap: 8.9,
      urgency: 8.8
    },
    timeSavedMinutes: 85,
    createdDate: 'Today, 08:10 AM'
  },
  {
    id: 'task-3',
    taskName: 'Generative Engine Optimization (GEO) for Ad Fraud Verification',
    category: 'GEO',
    subcategory: 'AI Citation & Knowledge Entity Expansion',
    priority: 'high',
    status: 'ai_detected',
    url: 'https://www.mfilterit.com/ad-traffic-validation/',
    targetKeyword: 'best ad fraud detection software 2026',
    channel: 'Website Solutions + Perplexity / ChatGPT Citations',
    signal: 'Perplexity and Google AI Overviews cite DoubleVerify and CHEQ in 83% of responses for "enterprise ad fraud validation", while mFilterIt is cited in only 18%.',
    evidence: 'Competitors have dedicated benchmark statistics, clear citation-worthy research blocks, and schema entity relationships with MRC accreditation mentions.',
    diagnosis: 'mFilterIt lacks standalone data citations, percentage benchmark callouts, and semantic entity linkages (Wikidata/schema) that LLMs require to quote sources.',
    reason: 'LLMs synthesize answers based on verified entity triples, numeric statistics, and authoritative comparative tables rather than marketing prose.',
    recommendedAction: 'Add a verified "2026 Ad Fraud Benchmark Data" table + integrate Organization & Product schema with sameAs links + publish a quote-friendly takeaway card.',
    expectedOutcome: 'Increase mFilterIt citation frequency in Perplexity and ChatGPT enterprise queries from 18% to over 60%.',
    approvalRequired: true,
    prioritizationScore: 91,
    scoreFactors: {
      businessImpact: 9.5,
      searchOpportunity: 9.0,
      competitorPressure: 9.8,
      contentGap: 8.7,
      urgency: 8.6
    },
    timeSavedMinutes: 110,
    createdDate: 'Today, 08:30 AM'
  },
  {
    id: 'task-4',
    taskName: 'eCommerce Brand Safety & Counterfeit Seller Detection',
    category: 'Distribution',
    subcategory: 'Multi-Channel B2B Distribution & UTM Packaging',
    priority: 'medium',
    status: 'ai_recommended',
    url: 'https://www.mfilterit.com/blog/ecommerce-brand-infringement-monitoring/',
    targetKeyword: 'brand infringement monitoring on amazon and flipkart',
    channel: 'LinkedIn Carousel + Quora High-Intent Answer + Pinterest Pin',
    signal: 'Strong ranking performance (Position 4.1 on Google), but organic conversion rate is lagging behind top-of-funnel traffic.',
    evidence: 'High social engagement on D2C brand protection topics across LinkedIn and retail e-commerce groups, but mFilterIt has not distributed this asset in 90 days.',
    diagnosis: 'High-performing search content is under-leveraged on executive social channels where Brand Protection VPs and eCommerce Heads actively congregate.',
    reason: 'Repurposing existing high-performing technical insight into visual executive carousels unlocks immediate B2B pipeline without creating new articles from scratch.',
    recommendedAction: 'Generate 7-slide LinkedIn carousel ("7 Ways Counterfeit Sellers Drain D2C Margins") + answer top Quora brand safety question with UTM tracking.',
    expectedOutcome: 'Drive 400+ targeted senior e-commerce decision-maker visits with tracked UTM campaign links and inbound audit requests.',
    approvalRequired: true,
    prioritizationScore: 82,
    scoreFactors: {
      businessImpact: 8.4,
      searchOpportunity: 7.9,
      competitorPressure: 8.1,
      contentGap: 7.8,
      urgency: 8.6
    },
    timeSavedMinutes: 95,
    createdDate: 'Today, 09:05 AM'
  },
  {
    id: 'task-5',
    taskName: 'Click Fraud in Performance Max (PMax) Campaigns Optimization',
    category: 'Content',
    subcategory: 'Content Gap Expansion & Technical Deep Dive',
    priority: 'medium',
    status: 'ai_detected',
    url: 'https://www.mfilterit.com/blog/google-performance-max-fraud-prevention/',
    targetKeyword: 'google pmax click fraud',
    channel: 'Website Blog + Quora + Reddit Discussion Assessment',
    signal: 'Google Search Console search queries for "pmax click fraud" increased 140% QoQ.',
    evidence: 'mFilterIt ranks at position 14.8 with an outdated generic Google Ads article. Competitor Lunio published a dedicated 3,000-word PMax teardown last month.',
    diagnosis: 'Major content gap on automated bidding vulnerabilities, spam lead generation, and asset group placement manipulation.',
    reason: 'Performance Max adoption among digital marketers is at an all-time high, making PMax fraud a primary pain point for digital marketing heads.',
    recommendedAction: 'Expand article with dedicated PMax asset group invalid traffic analysis + lead form fraud mitigations + internal link to Web Fraud solution.',
    expectedOutcome: 'Move from page 2 (pos 14.8) to page 1 (pos 5-8), generating ~3,200 incremental monthly clicks.',
    approvalRequired: true,
    prioritizationScore: 85,
    scoreFactors: {
      businessImpact: 8.7,
      searchOpportunity: 9.4,
      competitorPressure: 8.5,
      contentGap: 9.2,
      urgency: 8.1
    },
    timeSavedMinutes: 120,
    createdDate: 'Today, 09:20 AM'
  },
  {
    id: 'task-6',
    taskName: 'Technical SEO: 404 URL Resolution & Broken Redirection Chain',
    category: 'Technical',
    subcategory: 'Crawl Budget & Link Equity Recovery',
    priority: 'high',
    status: 'awaiting_approval',
    url: 'https://www.mfilterit.com/solutions/ad-fraud/',
    targetKeyword: 'enterprise ad fraud prevention',
    channel: 'Website Server / .htaccess / Cloudflare',
    signal: 'Screaming Frog / GSC crawl detected 14 legacy URLs returning 404 errors with 186 referring domains.',
    evidence: 'Old product pages migrated in Q1 2026 are dropping backlink authority and leaking crawl equity away from core solution pages.',
    diagnosis: 'Broken 301 redirection mappings following the recent solutions architecture update.',
    reason: 'Fixing 301 redirects immediately recaptures accumulated PageRank and historical domain trust without any content production cost.',
    recommendedAction: 'Map 14 orphaned URLs to the canonical `/ad-traffic-validation/` and `/brand-safety/` hubs with clean 301 permanent redirects.',
    expectedOutcome: 'Restore backlink equity from 186 referring domains and resolve crawl errors for Googlebot.',
    approvalRequired: true,
    prioritizationScore: 92,
    scoreFactors: {
      businessImpact: 9.3,
      searchOpportunity: 8.8,
      competitorPressure: 8.0,
      contentGap: 7.5,
      urgency: 9.7
    },
    timeSavedMinutes: 60,
    createdDate: 'Today, 09:40 AM'
  },
  {
    id: 'task-7',
    taskName: 'ABM Intelligence: High-Value E-Commerce & FinTech Accounts in MENA',
    category: 'ABM',
    subcategory: 'Target Account Research & Custom Pain-Point Assets',
    priority: 'medium',
    status: 'ai_recommended',
    targetKeyword: 'ad fraud detection for middle east superapps',
    channel: 'Custom Research Brief & LinkedIn Executive One-Pager',
    signal: '5 tier-1 Gulf retail & banking enterprises (e.g. Noon, Al Rajhi, Careem) increased digital ad spend by 40% ahead of Ramadan & festive season.',
    evidence: 'Ad fraud spikes in MENA reach 34% in festive quarters due to heavy affiliate affiliate poaching and bot-driven promo code abuse.',
    diagnosis: 'Generic marketing does not resonate with MENA digital procurement directors who require localized GCC regulatory & payment fraud examples.',
    reason: 'Creating tailored account-specific insights (pain points, competitor displacement, local language nuances) boosts enterprise sales pipeline velocity.',
    recommendedAction: 'Prepare tailored ABM executive briefs highlighting affiliate attribution fraud + coupon stuffing for Noon & regional super-apps (Strictly zero automated cold emails).',
    expectedOutcome: 'Equip enterprise sales team with high-impact conversational assets for 12 strategic GCC accounts.',
    approvalRequired: true,
    prioritizationScore: 84,
    scoreFactors: {
      businessImpact: 9.1,
      searchOpportunity: 7.5,
      competitorPressure: 8.6,
      contentGap: 8.2,
      urgency: 8.7
    },
    timeSavedMinutes: 90,
    createdDate: 'Today, 10:00 AM'
  }
];

export const TIME_SAVING_BREAKDOWN = [
  { activity: 'Keyword & Opportunity Analysis', manualMinutes: 45, aiMinutes: 5, savedMinutes: 40 },
  { activity: 'Competitor Research & Gap Triage', manualMinutes: 60, aiMinutes: 8, savedMinutes: 52 },
  { activity: 'Blog & Content Health Audit', manualMinutes: 45, aiMinutes: 6, savedMinutes: 39 },
  { activity: 'Content Refresh & Plan Preparation', manualMinutes: 90, aiMinutes: 15, savedMinutes: 75 },
  { activity: 'Internal Linking Mapping', manualMinutes: 30, aiMinutes: 4, savedMinutes: 26 },
  { activity: 'Distribution Copy & Creative Structuring', manualMinutes: 60, aiMinutes: 10, savedMinutes: 50 },
  { activity: 'Multi-Channel UTM Parameter Building', manualMinutes: 25, aiMinutes: 2, savedMinutes: 23 },
  { activity: 'Cross-Channel Executive Reporting', manualMinutes: 75, aiMinutes: 10, savedMinutes: 65 }
];

export const COMPETITOR_EVENTS: CompetitorEvent[] = [
  {
    id: 'comp-1',
    competitorName: 'CHEQ',
    competitorUrl: 'https://cheq.ai/blog/meta-advantage-plus-invalid-traffic',
    eventDate: 'Yesterday, 4:15 PM',
    eventType: 'new_blog',
    title: 'The Hidden Cost of Invalid Traffic on Meta Advantage+ Shopping Campaigns',
    topic: 'Meta Advantage+ Fraud & Bot Placement',
    whatHappened: 'CHEQ published a 2,200-word research piece with proprietary benchmarks claiming 19.4% invalid traffic in Advantage+ campaigns.',
    isRelevantToMFilterIt: true,
    relevanceReason: 'mFilterIt has a core solution for Meta ad validation. If CHEQ dominates the narrative on Advantage+ fraud, mFilterIt risks losing search and brand perception.',
    suggestedAction: 'Do NOT write a duplicate blog. Instead, immediately refresh mFilterIts existing "Meta Ads Click Fraud Detection" article with our proprietary verification data, add 4 AEO question blocks, and publish a LinkedIn carousel.',
    mFilterItActionType: 'refresh_existing',
    targetMFilterItPage: 'https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/'
  },
  {
    id: 'comp-2',
    competitorName: 'AppsFlyer Protect360',
    competitorUrl: 'https://www.appsflyer.com/resources/reports/fraud-report-2026',
    eventDate: '3 days ago',
    eventType: 'updated_blog',
    title: 'State of Mobile App Install Fraud 2026: The Rise of In-App Event Spoofing',
    topic: 'Mobile SDK & In-App Event Fraud',
    whatHappened: 'AppsFlyer updated their annual benchmark report with fresh mobile gaming and fintech data across APAC & MENA.',
    isRelevantToMFilterIt: true,
    relevanceReason: 'mFilterIt is a major player in APAC and MENA mobile app fraud prevention. Their report currently dominates generative AI search citations on Perplexity.',
    suggestedAction: 'Enrich mFilterIt Mobile App Fraud landing page with our unique device fingerprinting & behavioral biometric capabilities to recapture GEO citations.',
    mFilterItActionType: 'improve_geo',
    targetMFilterItPage: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/'
  },
  {
    id: 'comp-3',
    competitorName: 'DoubleVerify',
    competitorUrl: 'https://doubleverify.com/newsroom/dv-launches-retail-media-brand-safety',
    eventDate: '5 days ago',
    eventType: 'new_blog',
    title: 'Expanding Retail Media Network Brand Safety Verification',
    topic: 'Retail Media & Amazon/Walmart Advertising',
    whatHappened: 'DoubleVerify announced new verification metrics specifically targeting retail media networks (RMNs).',
    isRelevantToMFilterIt: true,
    relevanceReason: 'mFilterIt has an eCommerce Intelligence suite covering Amazon, Flipkart, Noon. We need to position our seller compliance and brand infringement capabilities alongside ad safety.',
    suggestedAction: 'Add a new dedicated section to mFilterIt eCommerce brand safety guide on "Retail Media Ad Fraud vs Counterfeit Seller Hijacking".',
    mFilterItActionType: 'add_section',
    targetMFilterItPage: 'https://www.mfilterit.com/blog/ecommerce-brand-infringement-monitoring/'
  },
  {
    id: 'comp-4',
    competitorName: 'HUMAN Security',
    competitorUrl: 'https://humansecurity.com/learn/blog/account-takeover-lead-generation',
    eventDate: '1 week ago',
    eventType: 'new_keyword',
    title: 'Lead Generation Bot Fraud in B2B Performance Marketing',
    topic: 'Lead Form Fraud & B2B Invalidation',
    whatHappened: 'HUMAN began capturing top 3 rankings for "fake lead detection in performance marketing".',
    isRelevantToMFilterIt: true,
    relevanceReason: 'mFilterIt provides Lead Validation solutions for insurance, edtech, and real estate clients.',
    suggestedAction: 'Create supporting FAQ answers and direct answer blocks on mFilterIt Web Fraud page to capture zero-click snippet opportunities.',
    mFilterItActionType: 'add_faq',
    targetMFilterItPage: 'https://www.mfilterit.com/blog/google-performance-max-fraud-prevention/'
  }
];

export const AEO_OPPORTUNITIES: AeoOpportunity[] = [
  {
    id: 'aeo-1',
    question: 'How do fraudsters fake Meta Advantage+ conversions?',
    currentCoverage: 'Zero explicit mention in existing blog. General click fraud discussed only.',
    gap: 'Lacks conversational definition of headless browser automation and pixel-event firing.',
    recommendedAnswer: 'Fraudsters fake Meta Advantage+ conversions using automated headless browsers that trigger synthetic Add-to-Cart and Lead events, tricking Meta algorithmic machine learning into allocating ad budget toward bot-infested placements rather than genuine buyers.',
    why: 'Direct 48-word answer-first format matches Google Featured Snippet & Perplexity response syntax perfectly.',
    serpType: 'Featured Snippet',
    targetUrl: 'https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/',
    status: 'pending'
  },
  {
    id: 'aeo-2',
    question: 'What is the difference between Device Spoofing and SDK Spoofing in app fraud?',
    currentCoverage: 'Discussed across 8 scattered paragraphs with high jargon.',
    gap: 'No side-by-side comparison table or 2-sentence crisp differentiation.',
    recommendedAnswer: 'Device spoofing alters device parameters (IMEI, IP, OS) on real hardware to fake multiple installs, whereas SDK spoofing injects simulated API calls directly into attribution servers without ever downloading the app.',
    why: 'Definition queries are the #1 source of People Also Ask (PAA) boxes in marketing tech.',
    serpType: 'People Also Ask',
    targetUrl: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
    status: 'pending'
  },
  {
    id: 'aeo-3',
    question: 'Can Google Ads automatically refund money lost to invalid clicks?',
    currentCoverage: 'Mentioned vaguely in conclusion as "Google gives credits".',
    gap: 'Missing exact criteria for Google Click Quality Team automated credits vs third-party verification necessity.',
    recommendedAnswer: 'While Google Ads automatically filters known bot IPs and issues automatic credits, sophisticated attribution fraud, click farm rings, and affiliate hijacking slip through default filters, necessitating independent third-party verification for full claim audits.',
    why: 'Ranks on page 1 for query intent; direct answer will trigger Google AI Overview citation.',
    serpType: 'AI Overview',
    targetUrl: 'https://www.mfilterit.com/blog/google-performance-max-fraud-prevention/',
    status: 'pending'
  }
];

export const GEO_OPPORTUNITIES: GeoOpportunity[] = [
  {
    id: 'geo-1',
    entity: 'mFilterIt Ad Traffic Validation',
    platform: 'Perplexity',
    currentMentionStatus: 'Weak Citation',
    competitorDominance: 'CHEQ and DoubleVerify cited in 86% of answers for enterprise ad verification.',
    citationGap: 'Perplexity relies on structured comparison benchmarks and verified entity triples.',
    actionRequired: 'Add a verified "Ad Fraud Prevention Benchmark Data (2026)" table + Schema.org Product markup with mFilterIt MRC alignment citations.',
    targetUrl: 'https://www.mfilterit.com/ad-traffic-validation/',
    why: 'Generative AI search engines ingest verified tabular statistics as factual ground truth.',
    status: 'pending'
  },
  {
    id: 'geo-2',
    entity: 'Brand Infringement & MAP Monitoring',
    platform: 'ChatGPT',
    currentMentionStatus: 'Competitor Dominates',
    competitorDominance: 'Red Points and Corsearch cited for eCommerce counterfeit seller monitoring.',
    citationGap: 'mFilterIt brand protection documentation is fragmented across multiple PDFs rather than crawlable, quote-ready web pages.',
    actionRequired: 'Publish crawlable executive summaries on Amazon & Flipkart unauthorized reseller detection with schema sameAs citations.',
    targetUrl: 'https://www.mfilterit.com/blog/ecommerce-brand-infringement-monitoring/',
    why: 'LLMs require clean semantic HTML with clear entity definitions to recommend vendor solutions.',
    status: 'pending'
  },
  {
    id: 'geo-3',
    entity: 'App Install Attribution Fraud Verification',
    platform: 'Google AI Overviews',
    currentMentionStatus: 'Not Cited',
    competitorDominance: 'AppsFlyer Protect360 cited as single authoritative source.',
    citationGap: 'Google AI Overviews extract citations from sources with high topical density and co-occurrence of key entities.',
    actionRequired: 'Inject semantic entity keywords (MMP, SDK Spoofing, Click Flooding, Device Farm) in immediate proximity to mFilterIt proprietary detection models.',
    targetUrl: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
    why: 'Co-occurrence of verified entities instructs Google Gemini to associate mFilterIt as primary authority.',
    status: 'pending'
  }
];

export const INTERNAL_LINKS_DATA: InternalLinkOpportunity[] = [
  {
    id: 'link-1',
    sourceUrl: 'https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/',
    targetPageTitle: 'Click Fraud Detection in Google Ads',
    targetUrl: 'https://www.mfilterit.com/blog/click-fraud-in-google-ads/',
    suggestedAnchor: 'cross-channel click fraud detection',
    location: 'Section 3: "Why Single-Platform Ad Verification Fails"',
    reason: 'Contextually supports the argument that bots rotate across Meta and Google simultaneously, boosting PageRank for Google Ads guide.',
    status: 'pending'
  },
  {
    id: 'link-2',
    sourceUrl: 'https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/',
    targetPageTitle: 'Enterprise Ad Traffic Validation Solution',
    targetUrl: 'https://www.mfilterit.com/ad-traffic-validation/',
    suggestedAnchor: 'ad traffic validation platform',
    location: 'Section 5: "How Real-Time Filtering Protects ROAS"',
    reason: 'High-intent commercial solution page link to direct organic traffic down the enterprise sales funnel.',
    status: 'pending'
  },
  {
    id: 'link-3',
    sourceUrl: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
    targetPageTitle: 'Mobile Ad Fraud: Web vs App Attribution',
    targetUrl: 'https://www.mfilterit.com/blog/web-vs-app-fraud/',
    suggestedAnchor: 'mobile attribution vulnerabilities',
    location: 'Section 2: "SDK Spoofing and Click Injection Vectors"',
    reason: 'Strengthens topical cluster around mobile application security and MMP data integrity.',
    status: 'pending'
  }
];

export const SAMPLE_CAROUSEL_SLIDES: CarouselSlide[] = [
  {
    slideNumber: 1,
    type: 'Hook',
    headline: 'Your Meta Ads ROAS Is Lying To You (Here Is Why)',
    body: 'In 2026, over 22% of clicks from automated Advantage+ campaigns originate from sophisticated bot networks mimicking real buyer intent.',
    visualPrompt: 'Bold typography with high contrast dark purple and magenta gradient accent. Split screen icon showing synthetic bot vs human buyer.',
    status: 'pending'
  },
  {
    slideNumber: 2,
    type: 'Problem',
    headline: 'The Problem: The Advantage+ Black Box',
    body: 'Meta algorithms are optimized to find the fastest conversions. When bots fake early funnel actions (add-to-cart, lead submits), the algorithm doubles down on fake audiences.',
    bulletPoints: [
      'Fake micro-conversions poison machine learning models',
      'Audience Network placement bleeding budget',
      'Analytics show high CTR but near-zero real revenue'
    ],
    visualPrompt: 'Clean flow chart graphic showing ad spend spiraling into bot clusters.',
    status: 'pending'
  },
  {
    slideNumber: 3,
    type: 'Why it happens',
    headline: 'Why Standard Filters Fail in 2026',
    body: 'Legacy ad verification looks for simple IP repeating and browser user-agents. Modern fraud rings deploy residential proxies and human behavioral emulation.',
    bulletPoints: [
      'Rotating mobile 5G residential IP pools',
      'Realistic cursor jitter and viewport scrolling',
      'Synthetic cookies mimicking aged purchase histories'
    ],
    visualPrompt: 'Comparison matrix: Traditional Rules-Based vs AI Behavioral Biometrics.',
    status: 'pending'
  },
  {
    slideNumber: 4,
    type: 'Key signals',
    headline: '4 Red Flags In Your Meta Ads Manager',
    body: 'Check these immediate anomalies in your dashboard:',
    bulletPoints: [
      'Sudden spikes in CTR with 90%+ bounce rate in GA4',
      'Conversion timestamps clustered within seconds across midnight',
      'Spike in Audience Network impressions with zero retention',
      'Duplicate phone prefixes or burner domains in lead forms'
    ],
    visualPrompt: 'Dashboard mock card highlighting 4 warning gauges with amber/red metrics.',
    status: 'pending'
  },
  {
    slideNumber: 5,
    type: 'Impact',
    headline: 'The Real Financial Cost: Not Just Lost Ad Spend',
    body: 'The real damage goes far beyond the $10,000 lost in wasted media spend:',
    bulletPoints: [
      'Distorted CAC & LTV calculations for your executive board',
      'Sales teams wasting 40% of their day calling fake phone numbers',
      'Retargeting pixels trained on non-human entities'
    ],
    visualPrompt: 'Iceberg infographic: Wasted media spend above water, distorted business data below.',
    status: 'pending'
  },
  {
    slideNumber: 6,
    type: 'What marketers should do',
    headline: 'What Modern Growth Leaders Do Differently',
    body: 'Take control of your campaign data with 3 immediate execution steps:',
    bulletPoints: [
      'Implement real-time invalid traffic pre-bid / post-bid filtering',
      'Cleanse offline conversion APIs before feeding back into Meta',
      'Enforce independent, cross-channel fraud audit protocols'
    ],
    visualPrompt: 'Step-by-step 3 pillar roadmap icon design in mFilterIt violet and white.',
    status: 'pending'
  },
  {
    slideNumber: 7,
    type: 'CTA',
    headline: 'Stop Paying For Bot Clicks. Audit Your Meta Ads Free.',
    body: 'Run an independent invalid traffic audit on your Meta and Google ad spend. Discover how much budget is bleeding to bot networks.',
    bulletPoints: [
      'Zero SDK or code injection required',
      'Full campaign breakdown in 48 hours',
      'Visit mfilterit.com/ad-traffic-validation'
    ],
    visualPrompt: 'Strong mFilterIt branding with Deep Purple background, QR code, and CTA button.',
    status: 'pending'
  }
];

export const TECHNICAL_SEO_ISSUES: TechnicalSeoIssue[] = [
  {
    id: 'tech-1',
    severity: 'Critical',
    issueType: '404 Error',
    url: 'https://www.mfilterit.com/solutions/ad-fraud/',
    problem: '14 legacy URLs returning 404 HTTP status codes.',
    evidence: 'GSC Crawl report shows 380 crawl errors; Ahrefs identifies 186 valuable external backlinks pointing to dead URLs.',
    impact: 'Loss of historical backlink PageRank equity and wasted Googlebot crawl budget.',
    recommendedFix: 'Implement server-level 301 permanent redirect rules to canonical `/ad-traffic-validation/` hub.',
    status: 'open'
  },
  {
    id: 'tech-2',
    severity: 'Critical',
    issueType: 'Core Web Vitals',
    url: 'https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/',
    problem: 'LCP (Largest Contentful Paint) is 3.8s on mobile devices (Google benchmark is < 2.5s).',
    evidence: 'Uncompressed 1.8MB PNG hero illustration and third-party tracking scripts blocking main thread.',
    impact: 'Mobile rank suppression on Google mobile-first indexing; poor visitor engagement rate.',
    recommendedFix: 'Convert hero images to WebP format with responsive srcset + defer non-critical analytics scripts.',
    status: 'open'
  },
  {
    id: 'tech-3',
    severity: 'Needs Attention',
    issueType: 'Schema Markup',
    url: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
    problem: 'Missing structured FAQPage and Article author schema.',
    evidence: 'Schema validator reports zero structured data entities found on page.',
    impact: 'Inability to generate rich snippets, FAQ accordion dropdowns, or AI search citations.',
    recommendedFix: 'Inject validated JSON-LD schema with Article, Author, and FAQPage entities.',
    status: 'open'
  },
  {
    id: 'tech-4',
    severity: 'Needs Attention',
    issueType: 'Canonical',
    url: 'https://www.mfilterit.com/brand-safety?utm_source=linkedin',
    problem: 'Self-referencing canonical tag missing on query parameter variants.',
    evidence: 'Search Console indexed 3 parameterized URLs as duplicate content.',
    impact: 'Keyword cannibalization and split ranking signals.',
    recommendedFix: 'Ensure strict canonical declaration to base URL without URL parameters.',
    status: 'open'
  },
  {
    id: 'tech-5',
    severity: 'Healthy',
    issueType: 'Sitemap',
    url: 'https://www.mfilterit.com/sitemap_index.xml',
    problem: 'XML sitemap verified and cleanly parsed by Googlebot.',
    evidence: 'Last crawled 6 hours ago with 100% 200 OK status on all listed pages.',
    impact: 'Optimal crawl efficiency for all published articles.',
    recommendedFix: 'No action required; maintain automated daily ping on new blog publication.',
    status: 'resolved'
  }
];

export const ABM_ACCOUNTS: AbmAccount[] = [
  {
    id: 'abm-1',
    companyName: 'Noon (GCC eCommerce Super-App)',
    domain: 'noon.com',
    industry: 'eCommerce & D2C',
    region: 'MENA (UAE/KSA)',
    adSpendTier: '$2M+/mo',
    keyPersonas: [
      {
        title: 'VP of Growth & Performance Marketing',
        focus: 'ROAS protection on Meta, TikTok & Google PMax during festive Ramadan sales.',
        painPoint: 'Affiliate partner attribution theft and automated bot coupon scraping.'
      },
      {
        title: 'Head of Marketplace & Brand Safety',
        focus: 'Preventing unauthorized 3P counterfeit electronics sellers.',
        painPoint: 'Manual seller auditing cannot keep up with thousands of daily catalog additions.'
      }
    ],
    suspectedFraudTypes: ['Affiliate Cookie Stuffing', 'Counterfeit Reseller Listings', 'PMax Bot Traffic'],
    contentAngle: 'Ramadan 2026 E-Commerce Fraud Brief: How Middle East Super-Apps Protect $4M+ in Seasonal Promotional Budgets.',
    creativeAssetConcept: 'Executive 1-Pager: "Noon Festive Shield: Stopping Affiliate Attribution Poaching in KSA & UAE"',
    competitorUsed: 'Currently testing AppsFlyer basic fraud filter; lacks brand protection capabilities.'
  },
  {
    id: 'abm-2',
    companyName: 'Al Rajhi Bank (Digital Banking & Tahweel)',
    domain: 'alrajhibank.com.sa',
    industry: 'FinTech & Banking',
    region: 'MENA (UAE/KSA)',
    adSpendTier: '$100k-$500k/mo',
    keyPersonas: [
      {
        title: 'Chief Marketing Officer',
        focus: 'Brand compliance and executive reputation across Arabic social media.',
        painPoint: 'Phishing domains and fake WhatsApp customer care accounts targeting banking users.'
      },
      {
        title: 'Head of Digital Acquisition',
        focus: 'High-quality personal loan and credit card applicant leads.',
        painPoint: 'Lead generation agencies submitting bot-filled loan forms.'
      }
    ],
    suspectedFraudTypes: ['Fake Lead Generation', 'Domain Spoofing / Phishing', 'Brand Impersonation on X/Meta'],
    contentAngle: 'Saudi Banking Compliance & Brand Protection: Defending Digital Banking Portals Against Impersonation & Invalid Leads.',
    creativeAssetConcept: 'C-Suite Brief: "Zero-Trust Lead Verification for GCC Financial Institutions"',
    competitorUsed: 'None dedicated; relying on internal security team.'
  },
  {
    id: 'abm-3',
    companyName: 'Nykaa (D2C Beauty & Fashion)',
    domain: 'nykaa.com',
    industry: 'eCommerce & D2C',
    region: 'India',
    adSpendTier: '$500k-$2M/mo',
    keyPersonas: [
      {
        title: 'Performance Marketing Director',
        focus: 'Meta and Google Performance Max invalid click suppression.',
        painPoint: 'Audience network invalid clicks during Pink Friday and seasonal sales.'
      },
      {
        title: 'Brand Protection Counsel',
        focus: 'Unauthorized luxury cosmetics diversion and expired batches on marketplaces.',
        painPoint: 'Grey-market sellers bypassing authorized distributor channels.'
      }
    ],
    suspectedFraudTypes: ['PMax Click Fraud', 'Grey-Market Divergence', 'Affiliate Poaching'],
    contentAngle: 'Beauty & Luxury D2C Fraud Defense: Protecting High-Margin ROAS and Authorized Seller Networks.',
    creativeAssetConcept: 'Benchmark Study: "Invalid Traffic in Indian Beauty D2C Campaigns: A $12M Blind Spot"',
    competitorUsed: 'CHEQ evaluated; mFilterIt local team & eCommerce intelligence offers stronger fit.'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'log-1',
    timestamp: 'Today, 08:45 AM',
    taskName: 'Meta Ads Fraud Detection & Invalid Clicks Refresh',
    category: 'SEO / Content',
    dataUsed: ['GSC 28-day impression drop (-28%)', 'Competitor CHEQ article analysis', 'Top 5 PAA queries'],
    recommendation: 'Refresh existing article with Advantage+ fraud section, add 5 AEO answers, and deploy LinkedIn carousel.',
    reason: 'Asset holds 18 months of search authority; refreshing recaptures rankings faster than new URL.',
    aiOutputSnippet: 'Generated 1,400-word technical refresh, 3 structured definition blocks, and 7-slide carousel copy.',
    userApproval: 'Approved by Minakshi',
    status: 'approved',
    timeSavedMinutes: 135
  },
  {
    id: 'log-2',
    timestamp: 'Today, 09:15 AM',
    taskName: 'Mobile App Install Fraud FAQ & Schema Generation',
    category: 'AEO',
    dataUsed: ['GSC Question Query reports', 'Featured snippet gap vs Adjust', 'Schema.org standards'],
    recommendation: 'Deploy direct definition blocks for SDK spoofing vs device spoofing + JSON-LD schema.',
    reason: 'Answers directly target Google Featured Snippet and zero-click query requirements.',
    aiOutputSnippet: 'Drafted 3 concise 45-word direct answer blocks and validated FAQPage schema JSON.',
    userApproval: 'Pending Review',
    status: 'awaiting_approval',
    timeSavedMinutes: 85
  },
  {
    id: 'log-3',
    timestamp: 'Yesterday, 04:30 PM',
    taskName: 'Multi-Channel UTM Generation for Brand Protection Hub',
    category: 'Distribution',
    dataUsed: ['mFilterIt eCommerce hub URL', 'Channel taxonomy matrix', 'Quarterly campaign codes'],
    recommendation: 'Generate tagged UTM URLs for LinkedIn, Quora, Substack, and Reddit distribution.',
    reason: 'Ensure 100% attribution tracking across non-paid referral channels in GA4.',
    aiOutputSnippet: 'Created 6 verified UTM URLs with consistent source/medium parameters.',
    userApproval: 'Approved by Minakshi',
    status: 'completed',
    timeSavedMinutes: 25
  },
  {
    id: 'log-4',
    timestamp: 'Yesterday, 02:10 PM',
    taskName: 'Technical Crawl: 404 Broken Backlink Equity Rescue',
    category: 'Technical',
    dataUsed: ['Screaming Frog crawl', 'Ahrefs 186 referring domain backlink report'],
    recommendation: 'Permanent 301 redirection mapping for 14 orphaned URLs.',
    reason: 'Immediately stops PageRank dilution and recovers inbound link juice.',
    aiOutputSnippet: 'Generated Apache / Cloudflare 301 redirection rules mapping.',
    userApproval: 'Approved by Minakshi',
    status: 'completed',
    timeSavedMinutes: 60
  }
];

export const INITIAL_UTM_LINKS: UtmLinkItem[] = [
  {
    id: 'utm-1',
    channel: 'LinkedIn Carousel',
    baseUrl: 'https://www.mfilterit.com/ad-traffic-validation/',
    source: 'linkedin',
    medium: 'social_carousel',
    campaign: 'meta_advantage_plus_fraud_2026',
    content: 'slide_cta_audit',
    term: 'ad_fraud_prevention',
    fullUrl: 'https://www.mfilterit.com/ad-traffic-validation/?utm_source=linkedin&utm_medium=social_carousel&utm_campaign=meta_advantage_plus_fraud_2026&utm_content=slide_cta_audit&utm_term=ad_fraud_prevention',
    clicks: 142
  },
  {
    id: 'utm-2',
    channel: 'Quora High-Intent Answer',
    baseUrl: 'https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/',
    source: 'quora',
    medium: 'referral_qa',
    campaign: 'how_to_detect_click_fraud',
    content: 'direct_answer_citation',
    term: 'meta_ads_fraud',
    fullUrl: 'https://www.mfilterit.com/blog/meta-ads-click-fraud-detection/?utm_source=quora&utm_medium=referral_qa&utm_campaign=how_to_detect_click_fraud&utm_content=direct_answer_citation&utm_term=meta_ads_fraud',
    clicks: 88
  },
  {
    id: 'utm-3',
    channel: 'Reddit B2B Discussion',
    baseUrl: 'https://www.mfilterit.com/blog/google-performance-max-fraud-prevention/',
    source: 'reddit',
    medium: 'community_discussion',
    campaign: 'pmax_lead_quality_discussion',
    content: 'educational_case_study',
    term: 'pmax_bot_traffic',
    fullUrl: 'https://www.mfilterit.com/blog/google-performance-max-fraud-prevention/?utm_source=reddit&utm_medium=community_discussion&utm_campaign=pmax_lead_quality_discussion&utm_content=educational_case_study&utm_term=pmax_bot_traffic',
    clicks: 215
  },
  {
    id: 'utm-4',
    channel: 'Pinterest Technical Infographic',
    baseUrl: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/',
    source: 'pinterest',
    medium: 'visual_infographic',
    campaign: 'app_install_fraud_architecture',
    content: 'sdk_spoofing_diagram',
    term: 'mobile_ad_fraud',
    fullUrl: 'https://www.mfilterit.com/blog/mobile-app-install-fraud-prevention/?utm_source=pinterest&utm_medium=visual_infographic&utm_campaign=app_install_fraud_architecture&utm_content=sdk_spoofing_diagram&utm_term=mobile_ad_fraud',
    clicks: 64
  }
];
