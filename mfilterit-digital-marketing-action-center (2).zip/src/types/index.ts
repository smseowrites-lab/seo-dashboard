export type PriorityLevel = 'high' | 'medium' | 'low';

export type TaskStatus = 
  | 'ai_detected' 
  | 'ai_recommended' 
  | 'awaiting_approval' 
  | 'ai_processing' 
  | 'approved' 
  | 'completed' 
  | 'needs_revision' 
  | 'skipped';

export interface TaskRecommendation {
  id: string;
  taskName: string;
  category: 'SEO' | 'AEO' | 'GEO' | 'Content' | 'Distribution' | 'ABM' | 'Technical';
  subcategory: string;
  priority: PriorityLevel;
  status: TaskStatus;
  url?: string;
  targetKeyword?: string;
  channel?: string;
  
  // The mandatory 9-point rule:
  // Signal → Evidence → Diagnosis → Reason → Recommended Action → Channel → Priority → Expected Outcome → Approval
  signal: string;
  evidence: string;
  diagnosis: string;
  reason: string;
  recommendedAction: string;
  expectedOutcome: string;
  approvalRequired: boolean;
  
  // Prioritization score & factors
  prioritizationScore: number; // 0 - 100
  scoreFactors: {
    businessImpact: number; // /10
    searchOpportunity: number; // /10
    competitorPressure: number; // /10
    contentGap: number; // /10
    urgency: number; // /10
  };

  // Execution Data
  timeSavedMinutes: number;
  outputSummary?: string;
  createdDate: string;
}

export interface InternalLinkOpportunity {
  id: string;
  sourceUrl: string;
  targetPageTitle: string;
  targetUrl: string;
  suggestedAnchor: string;
  location: string;
  reason: string;
  status: 'pending' | 'applied' | 'rejected';
}

export interface CarouselSlide {
  slideNumber: number;
  type: 'Hook' | 'Problem' | 'Why it happens' | 'Key signals' | 'Impact' | 'What marketers should do' | 'CTA';
  headline: string;
  body: string;
  bulletPoints?: string[];
  visualPrompt: string;
  status: 'pending' | 'approved' | 'rejected' | 'editing';
}

export interface CompetitorEvent {
  id: string;
  competitorName: string;
  competitorUrl: string;
  eventDate: string;
  eventType: 'new_blog' | 'updated_blog' | 'new_keyword' | 'ai_citation' | 'campaign';
  title: string;
  topic: string;
  whatHappened: string;
  isRelevantToMFilterIt: boolean;
  relevanceReason: string;
  suggestedAction: string;
  mFilterItActionType: 'refresh_existing' | 'add_section' | 'add_faq' | 'improve_aeo' | 'improve_geo' | 'build_links' | 'create_new_blog' | 'create_carousel';
  targetMFilterItPage?: string;
}

export interface AeoOpportunity {
  id: string;
  question: string;
  currentCoverage: string;
  gap: string;
  recommendedAnswer: string;
  why: string;
  serpType: 'Featured Snippet' | 'People Also Ask' | 'AI Overview' | 'Direct Answer';
  targetUrl: string;
  status: 'pending' | 'optimized';
}

export interface GeoOpportunity {
  id: string;
  entity: string;
  platform: 'ChatGPT' | 'Gemini' | 'Perplexity' | 'Google AI Overviews' | 'All';
  currentMentionStatus: 'Not Cited' | 'Weak Citation' | 'Competitor Dominates' | 'Top Citation';
  competitorDominance: string;
  citationGap: string;
  actionRequired: string;
  targetUrl: string;
  why: string;
  status: 'pending' | 'optimized';
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  taskName: string;
  category: string;
  dataUsed: string[];
  recommendation: string;
  reason: string;
  aiOutputSnippet: string;
  userApproval: 'Auto-prepared' | 'Approved by Minakshi' | 'Revised by Minakshi' | 'Pending Review';
  status: TaskStatus;
  timeSavedMinutes: number;
}

export interface AbmAccount {
  id: string;
  companyName: string;
  domain: string;
  industry: 'FinTech & Banking' | 'eCommerce & D2C' | 'Gaming & Apps' | 'EdTech' | 'Travel & Hospitality';
  region: 'India' | 'MENA (UAE/KSA)' | 'Southeast Asia' | 'US/Europe';
  adSpendTier: '$100k-$500k/mo' | '$500k-$2M/mo' | '$2M+/mo';
  keyPersonas: {
    title: string;
    focus: string;
    painPoint: string;
  }[];
  suspectedFraudTypes: string[];
  contentAngle: string;
  creativeAssetConcept: string;
  competitorUsed?: string;
}

export interface TechnicalSeoIssue {
  id: string;
  severity: 'Critical' | 'Needs Attention' | 'Healthy';
  issueType: '404 Error' | 'Redirect Loop' | 'Indexing' | 'Sitemap' | 'Canonical' | 'Core Web Vitals' | 'Schema Markup' | 'Image WebP';
  url: string;
  problem: string;
  evidence: string;
  impact: string;
  recommendedFix: string;
  status: 'open' | 'fixing' | 'resolved';
}

export interface UtmLinkItem {
  id: string;
  channel: string;
  baseUrl: string;
  source: string;
  medium: string;
  campaign: string;
  content: string;
  term?: string;
  fullUrl: string;
  clicks?: number;
}
