export interface CreativeSlide {
  slideNumber: number;
  type: 'Hook' | 'Problem' | 'Why it happens' | 'Key signals' | 'Impact' | 'What marketers should do' | 'CTA' | 'Hero' | 'Body' | 'Step';
  headline: string;
  body: string;
  bulletPoints?: string[];
  visualPrompt: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface CreativeVersion {
  id: string;
  versionNumber: number;
  label: string;
  createdAt: string;
  slides: CreativeSlide[];
  dimensions: string;
  colorPalette: string;
  designNotes: string;
  isApproved: boolean;
}

export interface CreativeChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  versionGeneratedId?: string;
  actionTriggered?: string;
}

export interface ApprovedCreativeStyle {
  id: string;
  name: string;
  platform: string;
  dimensions: string;
  colorPalette: string;
  typographyStyle: string;
  illustrationStyle: string;
  textDensity: string;
  cardStyle: string;
  approvedDate: string;
  sourceProjectName: string;
}

export interface ReferenceItem {
  id: string;
  name: string;
  category: 'Approved Designs' | 'Reference Images' | 'Templates' | 'Brand Styles' | 'LinkedIn Styles' | 'Blog Image Styles' | 'Infographic Styles';
  dimensions: string;
  tags: string[];
  thumbnailDescription: string;
  colorCodes: string[];
  promptGuide: string;
}

export interface CreativeProject {
  id: string;
  name: string;
  aiTitle: string;
  originalPrompt: string;
  platform: 'LinkedIn Carousel' | 'Website Blog Image' | 'Vertical Infographic' | 'Quora Infographic' | 'Pinterest Creative' | 'Presentation Deck';
  dimensions: string;
  category: 'carousel' | 'blog_image' | 'infographic';
  targetAudience: string;
  sourceBlogUrl?: string;
  createdAt: string;
  updatedAt: string;
  status: 'draft' | 'in_review' | 'approved' | 'sent_to_canva';
  canvaStatus: 'Ready to Sync' | 'Layout Packaged' | 'Exported';
  selectedTemplate: string;
  stylePreset: string;
  versions: CreativeVersion[];
  currentVersionId: string;
  conversation: CreativeChatMessage[];
  usedReferences: string[];
}
